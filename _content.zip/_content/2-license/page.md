---
title: License
_fieldset: license
_template: license
heroImages:
  - 
    image: /assets/img/homes/2l-20180413184411.jpg
    headline: License a Hudson Woods Design
    subHeadline: Find Out How To Build Your Own Hudson Woods House.
license_intro: Use the form below to tell us about your needs and we will be in touch with next steps
what_header: What Is The HW Design License?
what_explainer: A 224 page document of detailed drawings, specifications and material choices for replicating the Hudson Woods house.
what_grid:
  - 
    title: Ready-to-Build
    descriptor: Detailed Drawings And Specifications For Building The Hudson Woods House
  - 
    title: Construction Friendly
    descriptor: Tried And Tested For Replicating 30+ Houses
  - 
    title: 'Fixture, Finish & Materials'
    descriptor: 'Full Access To The Hudson Woods Partners & Suppliers.'
  - 
    title: Benchmark Timeline
    descriptor: 6-12 Month Timeline To Plan Against
how_header: How it Works
how_explainer: 5 steps to creating a Hudson Woods house on your property
how_grid:
  - 
    icon: /assets/img/GalleryArtboard 1@3x.png
    title: Acquire Land
    descriptor: Decide on your new or existing building plot.
  - 
    icon: /assets/img/GalleryArtboard 1 copy@3x.png
    title: HW Design
    descriptor: Purchase the Hudson Woods house design licence.
  - 
    icon: /assets/img/GalleryArtboard 1 copy 2@3x.png
    title: Hire Contractor
    descriptor: Choose the construction team to build your home to spec.
  - 
    icon: /assets/img/GalleryArtboard 1 copy 3@3x.png
    title: Secure Permit
    descriptor: File applications to obtain approval to build.
  - 
    icon: /assets/img/GalleryArtboard 1 copy 4@3x.png
    title: Construct House
    descriptor: Begin construction Est. 6-12 month timeline.
investment_header: What’s My Investment?
investment_explainer: 'Estimated construction cost between $400,000–$600,000 plus Land & Design Licence.'
license_header: License Options
license_grid:
  - 
    title: Individual
    descriptor: 1 Residence
    price: $35,000
  - 
    title: Developer
    descriptor: 10+ Residence
    price: $25,000
  - 
    title: Custom
    descriptor: ""
    price: Contact Us
faq_header: Frequently Asked Questions
faq_grid:
  - 
    title: What considerations should I have in mind when purchasing land?
    descriptor: 'How construction-ready is the land? Is it cleared and graded? Are plumbing, electric and cable connected? Are a road and driveway installed? The more a lot is construction ready, the lower your construction costs will be. '
  - 
    title: How do i go about identifying a qualified contractor?
    descriptor: We can recommend contractors in the area, but there are also a number of tools available such as Sweeten. Be sure to vet several contractors carefully and ask for 3 references from each contractor.
  - 
    title: Are your upgrade designs availbale to license?
    descriptor: Yes. Please contact us regarding which upgrades you would like to purchase. Cost can vary depending on the upgrade. Some items like the kitchen pantry, kitchen island and wood burning stove can be purchased directly.
  - 
    title: Can the standard house design be modified?
    descriptor: Modifications can be made directly by you with your contractor, or by a professional you hire to make drawing modifications for you. Our team can be hired to make modifications for you on an hourly fee basis.
  - 
    title: Do you offer any construction financing options?
    descriptor: 'We can connect you to lending partners in the area. However, a construction loan process is very similar to a mortgage process with 3rd party lending banks. '
  - 
    title: Will I need a local architect or engineer after purchasing a Design Licence?
    descriptor: An engineer is recommended to design your septic system or sewer connections. Your contractor or professionals you hire can secure building permits and approvals required by local municipalities.
license_disclaimer: "<p>All drawings, plans and specifications of a Hudson Woods home (hereinafter, the “Licensed Plans”) are only available pursuant to a signed license agreement (the “License Agreement”).  The visual effects of a finished structure constructed with the Licensed Plans, in a given location, may not necessary reflect the images depicted on this website, as all photographs and artist's renderings of the homes in the settings exhibited on this website are for representational and promotional purposes only.  The Licensed Plans shown represent the Hudson Woods model unit and are indicative of the base Hudson Woods home.  Consequently, actual configuration may vary to suit the site conditions of the land on which a home will be built.  All layouts and calculations are approximate and may vary.  All dimensions are approximations and subject to normal construction variances and tolerances.  Square footage exceeds the usable floor area.  Prices shown do not include any optional or custom features and all prices, availability, designs and specifications may change without notice.  All information provided herein is from sources deemed reliable, but no warranty or representation is made as to the accuracy thereof and same is submitted subject to errors, omissions, change of price or other conditions or withdrawal without notice.</p><p>Please be certain that the Licensed Plans you select suit your needs.  As every state, county or municipality may have its own building and code requirements, it is possible that the Licensed Plans may need to be modified to comply with such local requirements.  You may thus need to hire a licensed structural engineer experienced with such local requirements to provide necessary calculations and additional drawings in order to comply with such local requirements.  Any use of the Licensed Plans must be in accordance with the License Agreement and is conditioned on your obligation and agreement to strictly comply with all terms contained therein, and all local building codes, ordinances, regulations and requirements, including permits and inspections at the time of and during construction.  We recommend checking with your local building department for the most current requirements.</p><p>The original designer retains title and ownership of all plans. These materials are (c) Ridgewood Eco-Homes LLC. All copyrights, trademarks and service marks are the property of Ridgewood Eco-Homes LLC and may not be used without the permission of Ridgewood Eco-Homes LLC.</p><p>All pre-drawn plans from Architectural Designs do not carry a stamp from a licensed architect. If this is a requirement from your local building department, you will need to hire an architect or engineer to review and stamp the plans.</p>"
license_page_ntro: 'We are now offering the means to bring a Hudson Woods house to life on your own land or property you purchase. Put it in the woods, the mountains, near the ocean, or in a garden, and it immediately blends in with the surroundings. This was the vision behind our Hudson Woods  home.'
license_page_intro: We are now offering the means to bring a Hudson Woods house to life on your own land or property you purchase. Placed in the woods, the mountains, near the ocean, or in a garden, the home immediately blends in with the surroundings. This was the vision behind our Hudson Woods home.
---
