---
title: Contract Signed
_template: lots
_default_folder_template: lots
---
