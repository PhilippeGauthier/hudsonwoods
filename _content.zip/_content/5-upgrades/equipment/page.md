---
title: Equipment
_template: upgrades
_fieldset: upgrades_entry
_default_folder_template: upgrade_entry
_layout: upgrades
---

