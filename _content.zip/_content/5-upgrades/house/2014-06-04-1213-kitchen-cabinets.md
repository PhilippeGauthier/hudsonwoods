---
title: Kitchen Cabinets
categories:
  - house
specs:
  - 
    text: White oak upper cabinets
  - 
    text: Provides additional concealed storage in kitchen
previewImage: /assets/img/upgrades/cabinets.jpg
specDownload: ""
imageSingle: /assets/img/homes/cabinets-20140727014028.jpg
imageGallery: ""
---
<p>$3,500</p>