---
title: Kitchen Island
categories:
  - house
specs:
  - 
    text: Freestanding island built by local furniture maker
  - 
    text: Built from blackened steel with solid black walnut drawers and soapstone countertop
  - 
    text: Drawer dividers with integral knife block and customizable peg system in large drawer
previewImage: /assets/img/upgrades/Kitchen-Island-Thumbnail-20140709143017.jpg
imageGallery:
  - 
    image: /assets/img/homes/4-20140727020354.jpg
  - 
    image: /assets/img/homes/1-20140727020354.jpg
  - 
    image: /assets/img/homes/2-20140727020354.jpg
  - 
    image: /assets/img/homes/3-20140727020354.jpg
  - 
    image: /assets/img/homes/5-20140727020354.jpg
specDownload: ""
imageSingle: ""
---
<p>$17,000</p>