---
imageSingle: /assets/img/homes/Fridge2.jpg
title: Sub-Zero Refrigerator
categories:
  - house
specs:
  - 
    text: 15 Cubic feet of additional capacity
  - 
    text: 2 Freezer drawers with ice maker
previewImage: /assets/img/upgrades/Fridge3.jpg
imageGallery: ""
specDownload: ""
---
