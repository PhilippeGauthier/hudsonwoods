---
title: Copper Roofing
categories:
  - house
specs:
  - 
    text: Standing seam copper roofing
  - 
    text: 'Note: copper will patina with age'
previewImage: /assets/img/upgrades/copper.jpg
specDownload: ""
imageSingle: /assets/img/homes/1-20140727021006.jpg
imageGallery: ""
---
<p>$40,000</p>