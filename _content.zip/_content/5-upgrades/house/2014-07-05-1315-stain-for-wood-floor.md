---
title: Stain for Wood Floor
categories:
  - house
specs:
  - 
    text: Walnut-colored oil finish on wood floors through house
previewImage: /assets/img/upgrades/Oak.jpg
specDownload: ""
imageSingle: /assets/img/homes/2-20140727020951.jpg
imageGallery: ""
---
<p>$2,500</p>