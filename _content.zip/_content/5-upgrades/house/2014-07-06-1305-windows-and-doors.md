---
title: Windows and Doors
categories:
  - house
specs:
  - 
    text: Mahogany-framed, hinged insect screens at all operable windows and doors
  - 
    text: Oil rubbed bronze hardware
previewImage: /assets/img/upgrades/Window-screen-Thumbnail.jpg
specDownload: ""
imageSingle: /assets/img/homes/3-20140727020929.jpg
imageGallery: ""
---
<p>$7,500</p>