---
previewImage: /assets/img/upgrades/fruit-tree-thumbnail.jpg
title: Fruit Tree Grove
specs:
  - 
    text: 10 five-year-old fruit trees selected by a master gardener
  - 
    text: Planted, bermed, staked, mulched, irrigated and fenced in to protect them from deer
  - 
    text: Tree species may include Plum Sweet and Sour Cherry, Nectarine, Apple, Pear, Peach, Apricot
categories:
  - land
specDownload: ""
imageSingle: /assets/img/homes/Fruit-grove-Details-image.jpg
imageGallery: ""
---
<p>$10,500</p>