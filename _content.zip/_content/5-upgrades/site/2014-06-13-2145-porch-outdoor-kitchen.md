---
previewImage: /assets/img/upgrades/Untitled-1.gif
title: Porch / Outdoor Kitchen
categories:
  - site
specs:
  - 
    text: 400 sf
  - 
    text: Cedar framed screened porch pavilion
  - 
    text: Outdoor kitchen with stainless steel propane/charcoal hybrid grill, under counter refrigerator and cabinetry by Kalamazoo Outdoor Gourmet
  - 
    text: Concrete countertop
imageGallery:
  - 
    image: /assets/img/homes/1-20140727173846.jpg
  - 
    image: /assets/img/homes/2-20140727173846.jpg
  - 
    image: /assets/img/homes/3-20140727173846.jpg
specDownload: ""
imageSingle: ""
---
<p>$100,000</p>