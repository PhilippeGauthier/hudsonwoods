---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_CULTURE_Stormking.jpg'
title: 'Storm King Art Center       '
activity: Culture
---
<p>Over 100 intelligently sited&nbsp;works of the most acclaimed artists of our times dot the&nbsp;500 brilliantly landscaped&nbsp;acres of&nbsp;Storm King Arts Center, known as the world's finest sculpture park.&nbsp;Calder, Serra, Bourgeois, Dubuffet, Moore, Judd, Smith&hellip; An absolute must for the life list.&nbsp;</p><p><a href="http://www.stormkingartcenter.org/" target="_blank">stormkingartcenter.org</a></p>