---
title: Springwood Estate, home of FDR
activity: culture
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_CULTURE_springwood.jpg'
---
<p>Where Franklin Delano Roosevelt was born and lived throughout his life, this fabulous estate hosted kings, queens, prime ministers&nbsp;and politicians. It is is marvelously preserved,&nbsp;containing FDR's myriad collections of books and art, but it&nbsp;still remains "homey" for a mansion and inviting for a picnic on the grounds.&nbsp;</p><p><a href="http://www.nps.gov/hofr/index.htm" target="_blank">nps.gov/hofr/index.htm</a></p>