---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Aroma.jpg'
title: Aroma Thyme Bistro
activity: eat
---
<p>A restaurant that's certified Green and focuses on sourcing pure ingredients. The food is healthy and delicious, and the bar is well stocked, featuring 250 craft beers.</p><p><a href="http://www.aromathymebistro.com/" target="_blank">aromathymebistro.com</a></p>