---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_Rondout.jpg'
title: 'Rondout Valley Golf Club      '
activity: Swing
---
<p>Closest to Hudson Woods, and a&nbsp;moderately challenging course, the Rondout Valley Golf Club is 18 holes of beautiful scenery. We recommend afternoon play to catch the late light and after the&nbsp;18th enjoy the deck of Ivan's bar that looks out over the valley course.</p><p><a href="http://www.rondoutgolfclub.com" target="_blank">rondoutgolfclub.com</a></p>