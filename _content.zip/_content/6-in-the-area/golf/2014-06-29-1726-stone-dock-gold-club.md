---
title: Stone Dock Gold Club
activity: Swing
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_Stone-dock.jpg'
---
<p>An adorable 9 hole course sited on the Rondout Creek, Stone Dock&nbsp;Golf Club has experienced a great rejuvenation over the last several years. Though it is not without its challenges, the course is fun for all levels and features the added bonus of housing the quite delicious&nbsp;High Falls Café.</p><p><a href="http://www.stonedockgolfclub.com/" target="_blank">stonedockgolfclub.com</a></p>