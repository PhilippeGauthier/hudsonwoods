---
title: Zen Mountain Monastery
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_Zen.jpg'
---
<p>This&nbsp;is one of the most respected Zen Buddhist monasteries in the West, where monks are&nbsp;teaching and practicing&nbsp;ancient monasticism. Open to daily visits, retreats and other cultural&nbsp;programs to engage the dharma.&nbsp;The grounds&nbsp;are&nbsp;listed on the National Register of Historic Places.&nbsp;</p><p><a href="http://zmm.mro.org/" target="_blank">zmm.mro.org</a></p>