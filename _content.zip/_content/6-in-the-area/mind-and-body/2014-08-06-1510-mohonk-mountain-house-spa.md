---
title: Mohonk Mountain House Spa
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_Mohonk.jpg'
---
<p>Ranked the&nbsp;#1 resort spa by Condé Nast Traveller in 2013, the facility has 16 treatment rooms, fantastic views of the Catskills,&nbsp;a heated outdoor mineral pool and a "spa menu" that is actually&nbsp;28 pages long.&nbsp;</p><p><a href="http://www.mohonk.com/spa" target="_blank">mohonk.com/spa</a></p>