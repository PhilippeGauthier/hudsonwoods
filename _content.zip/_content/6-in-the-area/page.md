---
title: In The Area
_fieldset: in-the-area
_template: in-the-area
inTheAreaStay:
  - 
    title: Ashokan Resevoir
    image: '{{ _site_root }}assets/img/in-the-area/bird.JPG'
    content: '<p>The reservoir is in the eastern end of the Catskill Park, and is one of several reservoirs created to provide the City of New York with water.</p>'
heroImages:
  - 
    headline: In The Area
    subHeadline: ""
    image: '{{ _site_root }}assets/img/upgrades/Banner-image-Area-20140728163503.jpg'
activity: Sleep
---
