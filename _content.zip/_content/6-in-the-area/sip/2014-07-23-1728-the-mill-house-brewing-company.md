---
title: The Mill House Brewing Company
activity: Sip
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SIP_Millhouse.jpg'
---
<p>This cavernous&nbsp;brew-pub restaurant&nbsp;sits alongside&nbsp;its namesake&nbsp;brewery and currently&nbsp;serves 6 house made beers:&nbsp;Kold One, PK Pale Ale, Alpha, De Raileur, Kilt Spinnei and&nbsp;Velvet Panda Stout. We've had them at many of our events because it's all really good.&nbsp;Their motto:&nbsp;"Food, Farms, and beer."&nbsp;</p><p><a href="http://www.millhousebrewing.com/" target="_blank">millhousebrewing.com</a></p>