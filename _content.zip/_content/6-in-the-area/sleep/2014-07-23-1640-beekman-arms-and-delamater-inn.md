---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Beekman.jpg'
title: Beekman Arms and Delamater Inn
activity: Sleep
---
<p>America's oldest continuously operating inn has all the historic trappings one would expect:&nbsp;wide-plank floors, beamed ceilings, and a stone hearth. It&nbsp;contains the sturdy Bogardus Tavern,&nbsp;built to withstand an Indian attack&nbsp;and a stage coach stop and hangout for revolutionaries. Of course, George Washington slept here.&nbsp;Its&nbsp;"sister" inn, the Delameter is&nbsp;considered an American Gothic masterpiece.&nbsp;<a href="http://beekmandelamaterinn.com/">beekmandelamaterinn.com</a></p>