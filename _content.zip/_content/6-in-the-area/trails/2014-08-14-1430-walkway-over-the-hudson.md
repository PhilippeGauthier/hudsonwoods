---
title: Walkway over the Hudson
activity: Trails
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_TRAILS_Walkway-20140820165235.jpg'
---
<p>A formerly&nbsp;abandoned railroad bridge is now a glorious if somewhat&nbsp;vertiginous&nbsp;pedestrian park. The Walkway over the Hudson connects Highland to Poughkeepsie, and at1.28 miles, is the longest, elevated pedestrian bridge in the world. Among the more popular events scheduled there are the frequent "Moonwalks" and a very dramatic 4th of July.</p><p>http://walkway.org</p>