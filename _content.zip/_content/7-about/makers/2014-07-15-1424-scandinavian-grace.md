---
image: '{{ _site_root }}assets/img/makers/Scandinavian-Grace.png'
title: Scandinavian Grace
makerTitle: Scandinavian Grace
makerTagline: 'An eclectic mix of Scandinavian designed furniture & objects'
link: http://www.scandinaviangrace.com/
logo: '{{ _site_root }}assets/img/makers/ScandyGrace-Logo.jpg'
---
