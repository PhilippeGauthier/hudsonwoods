---
title: September Open House Schedule
author: HudsonWoods
categories:
  - architecture
  - hudson valley
  - open house
featuredImage: /assets/img/journal/IMG_4899-20150901173656.jpg
contentSummary: '<p>This month we will be holding an open house every Sunday from 11:00 AM - 1:00 PM. Take a tour of the model home, explore the surrounding area and meet with the Architect, Drew Lang who hosts the open house. We hope to see you there!</p>'
---
<p><img src="/assets/img/journal/resized/IMG_4899-20150901173624.jpg"></p><p>This month we will be holding an open house every Sunday from 11:00 AM - 1:00 PM. Take a tour of the model home, explore the surrounding area and meet with the Architect, Drew Lang who hosts the open house. We hope to see you there! The detailed schedule is shown below:</p><p>Sunday Sep. 6th - 11:00a to 1:00p<br>Sunday Sep. 13th - 11:00a to 1:00p<br>Sunday Sep. 20th - 11:00a to 1:00p<br>Sunday Sep. 27th - 11:00a to 1:00p</p><p><img src="/assets/img/journal/resized/hw_door.jpg"></p><p><img src="/assets/img/journal/resized/House.jpg"></p>