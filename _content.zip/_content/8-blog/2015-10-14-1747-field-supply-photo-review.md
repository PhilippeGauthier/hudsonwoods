---
title: 'Field+Supply: Photo Review'
author: HudsonWoods
featuredImage: /assets/img/journal/FSLead.jpg
contentSummary: '<p>A big thank you to everyone who stopped by to see us at <a href="http://www.fieldandsupply.com/" target="_blank">Field + Supply</a> last weekend. It was a spectacular success with twice the number exhibitors as last year, plus workshops and Tesla Test Drives! It is wonderful to see the creative community continue to grow and thrive in the Hudson Valley and surrounding areas. As we did <a href="http://hudsonwoods.com/blog/field-supply-part-2" target="_blank">last year</a>, we have collected a number of photos instagrammed during the 2 days of the event to share with you. </p>'
categories:
  - hudson valley
  - community
  - design
---
<p><img src="/assets/img/journal/resized/FSLead-20151014193047.jpg"></p><p>A big thank you to everyone who stopped by to see us at <a href="http://www.fieldandsupply.com/" target="_blank">Field + Supply</a> last weekend. It was a spectacular success with twice the number exhibitors as last year, plus workshops and Tesla Test Drives! It is wonderful to see the creative community continue to grow and thrive in the Hudson Valley and surrounding areas. As we did <a href="http://hudsonwoods.com/blog/field-supply-part-2" target="_blank">last year</a>, we have collected a number of photos instagrammed during the 2 days of the event to share with you. If you missed the event, search #fieldandsupply on instagram for a recap. Here are a few of our favorites. Photos By (Left To Right): @dominomag, @mjtraynor, @andnorth, @alyssadara, @clairecall, @kitrepublic, @amolleurstudio, @hudsonworkshop @the_shopkeepers @sheenamurph, @coldspringgeneral, @jaynejain</p><p><img src="/assets/img/journal/resized/FS-Collage.jpg"></p><p><br></p>