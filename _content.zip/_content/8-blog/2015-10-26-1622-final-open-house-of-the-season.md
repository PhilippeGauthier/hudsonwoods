---
title: Final Open House of the Season
author: HudsonWoods
featuredImage: /assets/img/journal/BLOG3-20151027155051.jpg
categories:
  - autumn
  - hudson woods
  - hudson valley
contentSummary: "<p>Stop by our final open house of the season this Sunday, November 1st, from 11:00a - 1:00p. The leaves are at peak foliage and it's one of our favorite times of year to visit the must see spots of the Hudson Valley before the frost arrives.</p>"
---
<p><img src="/assets/img/journal/resized/BLOG3.jpg"><br></p><p>Stop by our final open house of the season this Sunday, November 1st, from 11:00a - 1:00p. The leaves are at peak foliage and it's one of our favorite times of year to visit the must see spots of the Hudson Valley before the frost arrives.</p><p>After November 1st we will be holding viewings of the model house by appointment only. If you would like to schedule a viewing please contact us at sales@hudsonwoods.com. </p><p><img src="/assets/img/journal/resized/BLOG1-20151027103818.jpg"></p><p><img src="/assets/img/journal/resized/BLOG4.jpg"></p><p><img src="/assets/img/journal/resized/1-20151027121307.jpg"></p><p>Storm King Highway</p><p><img src="/assets/img/journal/resized/3-20151027121730.jpg"></p><p>Peak Foliage in the Hudson Valley</p><p><img src="/assets/img/journal/resized/5-20151027121740.jpg"></p><p>Ashokan Reservoir </p><p><img src="/assets/img/journal/resized/6-20151027121755.jpg"></p><p>Mohonk Perserve </p><p><img src="/assets/img/journal/resized/7-20151027121804.jpg"></p><p>Lake Minnewaska State Park</p><p><img src="/assets/img/journal/resized/BLOG2.jpg"></p>