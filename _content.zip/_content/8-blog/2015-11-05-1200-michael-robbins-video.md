---
title: 'From the Source: Michael Robbins'
author: HudsonWoods
featuredImage: /assets/img/journal/1-20151105120927.jpg
videoEmbed: '<iframe src="https://player.vimeo.com/video/103684916" width="500" height="263" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'
categories:
  - furniture
  - hudson valley
  - design
contentSummary: |
  <p>This week we wanted to share a beautiful video from our friend and one of our maker partners, Michael Robbins. As you may know, we have two of Michael's pieces at Hudson Woods; the Big Bend Chair and Wickson Chair. You can also find the Wickson Chair at the "UPSTATE" installation at Whisper in New York City which we helped to curate. Since we last covered Michael's work, he has been busy crafting a number of new creations. Here is a photo review of a few of his new pieces.</p>
---
<p>This week we wanted to share a beautiful video from our friend and one of our maker partners, <a href="http://www.mchlrbbns.com/" target="_blank">Michael Robbins</a>. As you may know, we have two of Michael's pieces at Hudson Woods; the Big Bend Chair and Wickson Chair. You can also find the Wickson Chair at the <a href="https://www.whispereditions.com/" target="_blank">"UPSTATE" installation at Whisper</a> in New York City which we helped to curate. Since we last covered Michael's work, he has been busy crafting a number of new creations. Here is a photo review of a few of his new pieces. </p><p><img src="/assets/img/journal/resized/1-20151105113208.jpg"><br></p><p><img src="/assets/img/journal/resized/2-20151105120618.jpg"></p><p><img src="/assets/img/journal/resized/3-20151105120627.jpg"><br></p><p><img src="/assets/img/journal/resized/4-20151105120654.jpg"></p><p><img src="/assets/img/journal/resized/5-20151105120702.jpg"></p><p><img src="/assets/img/journal/resized/6-20151105120709.jpg"><br></p><p><img src="/assets/img/journal/resized/7-20151105120716.jpg"></p><p><img src="/assets/img/journal/resized/8-20151105120723.jpg"></p>