---
title: New Lots Released at Hudson Woods
author: HudsonWoods
categories:
  - construction
  - architecture
  - hudson woods
featuredImage: /assets/img/journal/151023_HudsonWoods-0406-20151124182616.jpg
contentSummary: '<p>The fall months have been gorgeous and pleasant in the Hudson Valley. As the Autumn rolls along, we are excited to announce that we are moving into Phase 4 of construction at Hudson Woods. There are now 16 homes sold and only 10 lots are left available for purchase.<span></span></p>'
---
<p><img src="/assets/img/journal/resized/151023_HudsonWoods-0406-20151124181330.jpg"><br></p><p>The fall months have been gorgeous and pleasant in the Hudson Valley. As the Autumn rolls along, we are excited to announce that we are moving into Phase 4 of construction at Hudson Woods. There are now 16 homes sold and only 10 lots are left available for purchase. The next phase of lots comes with an associated price increase. Lots now start at $765,000 at 3.7 acres and range up to $915,000 at 7.1 Acres. Eight lots are currently available in total, you can see more details on our <a href="http://hudsonwoods.com/availability">availability page</a>.</p><p><img src="/assets/img/journal/resized/2-20151123184150.jpg"></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0236.jpg"></p><p><img src="/assets/img/journal/resized/4-20151123184218.jpg"></p><p><img src="/assets/img/journal/resized/5-20151123184227.jpg"></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0341-20151124182454.jpg"></p><p><img src="/assets/img/journal/resized/6-20151123184237.jpg"></p><p><img src="/assets/img/journal/resized/7-20151123184246.jpg"></p>