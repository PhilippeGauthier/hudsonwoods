---
title: 10 More "Upstate" Made Gifts From Our Collection for Whisper
author: HudsonWoods
featuredImage: /assets/img/journal/kitchen-tools2-1-20151218124234.jpg
contentSummary: '<p>Enjoy this second installment of goods from our Upstate maker friends and partners. Another great way to "shop local" if not in person, then in spirit.</p>'
categories:
  - hudson valley
  - craftsmanship
  - local made
---
<p><br></p><p>Enjoy this second installment of goods from our Upstate maker friends and partners. Another great way to "shop local" if not in person, then in spirit.<br><br></p><p><img src="/assets/img/journal/resized/blackcreek_mercantile__please credit Design Sponge & Max Tielman.jpg"></p><p><a href="http://www.blackcreekmt.com" target="_blank">Blackcreek Mercantile & Trading Co</a>     <strong>Kingston, NY</strong></p><p><strong></strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>75</o:Words>
  <o:Characters>429</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>3</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>526</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="line-height:normal">Joshua
Vogel created Blackcreek Mercantile & Trading Co. as a way to explore small
scale product design and manufacturing, & to reconnect himself with the
practice and idea of handmade goods. All of BCM’s products are made by people
in the Kingston, NY studio. The goal of BCM’s work is to
create enduring, beautiful, and functional objects that you will love to use.<br><br><br></p><p><img src="/assets/img/journal/resized/blackline-products.jpg"></p><p class="normal" style="line-height:normal"><a href="http://www.blackcreekmt.com/blackline-wood-products.html" target="_blank">Blackline Collection</a><br></p><p class="normal" style="line-height:normal"><br></p><p><img src="/assets/img/journal/resized/kitchen-tools2-1.jpg"></p><p><a href="http://www.blackcreekmt.com/kitchen_tools.html" target="_blank">Kitchen Tools</a></p><p><br></p><hr><p><img src="/assets/img/journal/resized/dam-images-shopping-2014-02-valentine-s-day-stationery-valentines-day-stationery-04-thornwillow-press-love-poem-cards.jpg"><br></p><p><a href="http://thornwillow.com" target="_blank">Thornwillow Press</a>   <strong>Newburgh, NY</strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>54</o:Words>
  <o:Characters>310</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>2</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>380</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><!--EndFragment--><p>Founded 30 years ago by Luke Ives Pontifell when he was still at Harvard, Thornwillow Press
is committed to the related arts and crafts of the written word. As printers
and publishers of handmade, limited edition books, custom book binders and
makers of fine, engraved stationery, Thornwillow has consolidated its workshops
in a complex of 19th Century brick factory buildings in Newburgh, NY. Their impeccable taste and quality has earned them the role of bespoke stationer to New York's St. Regis Hotel.<br><br></p><p><img src="/assets/img/journal/resized/fields-and-woods-metro-box_all_2.jpg"></p><p><a href="http://thornwillow.com/field-woods.html" target="_blank">Metropolitan Field & Wood Box</a></p><p><br></p><p><img src="/assets/img/journal/resized/continental_block_journals-20151218115249.jpg"></p><p><a href="http://thornwillow.com/metropolitan-block-journals-box.html" target="_blank">Metropolitan Block Journals</a></p><p><br></p><hr><p><img src="/assets/img/journal/resized/12339567_940625942657720_2003466574204785988_o.jpg"></p><p><a href="http://hudsonmadeny.com/collections/all" target="_blank">Hudson Made</a>     <strong>Andes, NY</strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>107</o:Words>
  <o:Characters>615</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>5</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>755</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p>A product's story is what rescues it from the assembly line and breathes
life into it. It gives the product room to be itself, to be original, and not
be stifled by standardization. Hudson Made reinvigorates the marketplace with
unique items made in the Hudson Valley. Their philosophy is a proposition of a return to the roots of America, a time when craftsmanship and quality were
valued above machinery and quantity. Quality means knowing a product's story,
which means knowing the artisan or farmer who crafted it, knowing from where
the product came and how far it traveled, and knowing what makes this product
unique and how it can enhance your life.</p><p><br></p><p><img src="/assets/img/journal/resized/10608413_799199770133672_8454157722469009221_o.jpg"></p><p><a href="http://hudsonmadeny.com/collections/all/products/aothecary-rose-soap" target="_blank">Apothecary Rose Soap</a> </p><p><br></p><p><img src="/assets/img/journal/resized/Scully.jpg"></p><p><a href="http://hudsonmadeny.com/collections/all/products/hudson-made-scullery-soap" target="_blank">Scullery Soa</a></p><p><br></p><p><img src="/assets/img/journal/resized/10841991_776881005698882_3633667911730403243_o-20151218120420.jpg"></p><p><a href="http://hudsonmadeny.com/collections/all/products/workers-soap" target="_blank">Worker's Soap</a></p><p><br></p><hr><p><img src="/assets/img/journal/resized/2-20151218121800.jpg"></p><p><a href="https://squareup.com/market/tree-juice-maple-syrup" target="_blank">Tree Juice Maple Syrup</a>     <strong>Olivbridge and Arkville, NY</strong><br></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>89</o:Words>
  <o:Characters>510</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>4</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>626</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="line-height:normal">Lazy Crazy Acres Farm is nestled in the
Drybrook Valley of the Catskills. The Fairbairn family have owned and operated
this 100+ acre farm since the 1930's. Jake Fairbairn and Ryan Annetts resurrected
the family's sugar shack and began making Maple Syrup.</p><p class="normal" style="line-height:normal">Over 1600 sugar maple trees are tapped.
Miles of sap-lines gravity feed the sap to storage tanks. A wood fired
evaporator then turns the sap into Tree Juice Maple Syrup. </p><p class="normal" style="line-height:normal">Tree Juice takes it’s syrup and fills used oak
bourbon barrels from <a href="http://www.tuthilltown.com" target="_blank">Tuthillton Distillery</a> in Gardiner, NY. After 8 months of aging, the result
is a rich tasting maple syrup with a hint of smoky oak bourbon.</p><p class="normal" style="line-height:normal"><br></p><p><img src="/assets/img/journal/resized/1-20151218121818.jpg"></p><!--EndFragment--><p><a href="https://squareup.com/market/tree-juice-maple-syrup" target="_blank">Bourbon Barrel Aged Maple Syrup</a> and <a href="https://squareup.com/market/tree-juice-maple-syrup" target="_blank">Vanilla Infused Maple Syrup</a></p><p><br></p><hr><p><img src="/assets/img/journal/resized/1-20151218122749.png"></p><p><a href="http://materiadesigns.com" target="_blank">Materia Designs</a>     <strong>Accord, NY</strong></p><p>Materia Designs strives to blur the lines between art, design,
utility, work and life. Drawing from their combined backgrounds in
choreography, fashion, landscape design and woodworking, owners Megan
Sommerville and Matt Ensner have developed an intuitive and responsive visual
language which informs their collections of furniture, lighting, accessories
and a growing portfolio of residential and commercial interiors projects.
Materia derives inspiration from the strong community of Hudson Valley artisans
whom they collaborate with, as well as the expansive rural landscape. <br></p><p><br></p><p><img src="/assets/img/journal/resized/Materia Pillow (1).png"></p><!--EndFragment--><p><a href="http://materiadesigns.com/products/comb-20-throw-pillow-grey-flax" target="_blank">Comb 20" Throw Pillow</a><br></p><p><br></p><p><img src="/assets/img/journal/resized/2-20151218122943.png"></p><p><a href="http://materiadesigns.com/products/gold-lined-calfskin-ipad-case" target="_blank">Gold Lined Calf Skinned iPad Case</a></p><p><br></p><p><img src="/assets/img/journal/resized/3-20151218123005.jpg"></p><p><a href="http://materiadesigns.com/products/mano-serving-platter" target="_blank">Mano Platter + Onam Vessel Set</a><br></p><p><br></p><hr><p><img src="/assets/img/journal/resized/HETTA-Beckons-e1414515899540.jpg"></p><p><a href="http://hettaglogg.com/find/" target="_blank">Hetta Glögg</a>    <strong>Rhinecliff, NY</strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>119</o:Words>
  <o:Characters>682</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>5</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>837</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="margin-top:0in;margin-right:3.0pt;margin-bottom:13.0pt;
margin-left:3.0pt;line-height:150%">Glögg, the Nordic term
for mulled wine, may not have much association with the Hudson Valley, but Hetta Glögg is a recently launched bottled version produced in small batches in Rhinecliff, NY. Traditionally offered
during the holidays and cold-weather months in the Nordic countries, the usually heated, aromatic
glögg is served as a festive, warming beverage for arriving guests. So we think it also pairs quite nicely with the Upstate climate.</p><p class="normal" style="margin-top: 0in; margin-right: 3pt; margin-bottom: 13pt; line-height: 150%;"> Hetta’s base wine is a tawny port, custom
produced by Swedish Hill Winery in the Finger Lakes. In the small Rhinecliff
workspace, they macerate orange peels, cinnamon sticks, ground
cardamom and raisins in a 275 gallon batch of the port for 10 days at room temperature.</p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>39</o:Words>
  <o:Characters>227</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>1</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>278</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="margin-top: 0in; margin-right: 3pt; margin-bottom: 13pt; line-height: 150%;">The mulled liquid is then combined with some fresh port and a dose of three-year-old brandy from Clear Creek (Oregon). The mixture
is then heated to 180 degrees and bottled—hot—four
bottles at a time. Heat it before serving to experience the aromas and the Nordic cheer.</p><p class="normal" style="margin-top: 0in; margin-right: 3pt; margin-bottom: 13pt; line-height: 150%;"><br></p><!--EndFragment--><hr><!--EndFragment--><p><img src="/assets/img/journal/resized/1-20151218123618.jpg"></p><p><a href="http://hawkinsnewyork.com" target="_blank">Hawkins NY</a>      <strong>Hudson, NY</strong></p><p><strong></strong>A curated lifestyle brand, fusing innovation, quality, and
aesthetics, Hawkins NY designs an exclusive line of products
with careful consideration of their producers around the world. They carefully pair
products to manufacturers and encourage handmade production by artisanal
collectives. Additionally, they collaborate with local designers to help facilitate
getting those designs to market and adding a bespoke layer to the overall collection.</p><p><br></p><p><img src="/assets/img/journal/resized/3-20151218123634.jpg"><br></p><!--EndFragment--><p><a href="http://hawkinsnewyork.com/shop/knot-quilt-collection" target="_blank">Knot Bedding Queen Quilt by Meg Callahan</a></p><p><br></p><p><img src="/assets/img/journal/resized/4-20151218123756.jpg"></p><p><a href="http://hawkinsnewyork.com/shop/grady-ladders" target="_blank">Grady Ladders</a></p><p><br></p><p><img src="/assets/img/journal/resized/2-20151218123829.jpg"></p><p><a href="http://hawkinsnewyork.com/shop/simple-linen-pillow" target="_blank">Simple Linen Pillows</a></p><p><br></p><hr><p><img src="/assets/img/journal/resized/Screen Shot 2015-06-03 at 11.32.31 AM-20150603115353-20151218123930.jpg"></p><p>Fruition Chocolate    <strong> Shokan, NY</strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>79</o:Words>
  <o:Characters>452</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>3</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>555</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="margin-bottom:15.0pt;line-height:157%">Fruition is a small batch bean to bar chocolate workshop
located at the foot of the Catskill Mountains. With meticulous
attention to detail, they slowly roast and stone grind carefully selected cocoa
beans (fair trade and organic of course) to accentuate their inherent flavor. </p><p class="normal" style="margin-bottom:15.0pt;line-height:157%">Founder Bryan Graham  graduated from the <a href="http://ciachef.edu/">Culinary Institute of America</a> in Hyde Park, New York, and completed an externship at <a href="http://mrchocolate.com/">Jacques Torres Chocolates</a> in NYC. An interest in the history of confectionery was sparked, and ever since he has educated himself on the
science, technique, and craft of handmade chocolate.</p><p class="normal" style="margin-bottom:15.0pt;line-height:157%"><br></p><p><img src="/assets/img/journal/resized/Screen Shot 2015-06-03 at 11.33.03 AM-20150603121107-20151218123955.jpg"></p><p class="normal" style="margin-bottom:15.0pt;line-height:157%"><a href="http://www.tastefruition.com/products/camino-crunch" target="_blank">Camino Verde Crunch</a>, <a href="http://www.tastefruition.com/products/dark-milk-with-flor-de-sal-chocolate-bar" target="_blank">Dark Milk with Flor De Sal</a> and <a href="http://www.tastefruition.com/products/brown-butter-milk-chocolate-bar" target="_blank">Brown Butter Milk Chocolate</a></p><p class="normal" style="margin-bottom:15.0pt;line-height:157%"><br></p><hr><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>49</o:Words>
  <o:Characters>281</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>2</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>345</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><!--EndFragment--><!--EndFragment--><p><img src="/assets/img/journal/resized/10444733_10153227300722661_3953341420844159054_n-20151218124025.jpg"></p><p><a href="http://www.seedlibrary.org" target="_blank">Hudson Valley Seed Library</a>     <strong>Accord, NY</strong><strong><br></strong></p><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Template>Normal.dotm</o:Template>
  <o:Revision>0</o:Revision>
  <o:TotalTime>0</o:TotalTime>
  <o:Pages>1</o:Pages>
  <o:Words>100</o:Words>
  <o:Characters>574</o:Characters>
  <o:Company>TBrittainStone</o:Company>
  <o:Lines>4</o:Lines>
  <o:Paragraphs>1</o:Paragraphs>
  <o:CharactersWithSpaces>704</o:CharactersWithSpaces>
  <o:Version>12.0</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG></o:AllowPNG>
 </o:OfficeDocumentSettings>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:Zoom>0</w:Zoom>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting></w:TrackFormatting>
  <w:PunctuationKerning></w:PunctuationKerning>
  <w:DrawingGridHorizontalSpacing>18 pt</w:DrawingGridHorizontalSpacing>
  <w:DrawingGridVerticalSpacing>18 pt</w:DrawingGridVerticalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>0</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas></w:ValidateAgainstSchemas>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:Compatibility>
   <w:BreakWrappedTables></w:BreakWrappedTables>
   <w:DontGrowAutofit></w:DontGrowAutofit>
   <w:DontAutofitConstrainedTables></w:DontAutofitConstrainedTables>
   <w:DontVertAlignInTxbx></w:DontVertAlignInTxbx>
  </w:Compatibility>
 </w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" LatentStyleCount="276">
 </w:LatentStyles>
</xml><![endif]--><!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin:0in;
	mso-para-margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman";
	mso-ascii-font-family:Cambria;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"ＭＳ 明朝";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Cambria;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--StartFragment--><p class="normal" style="margin-bottom:75.0pt;line-height:normal">The majority of these heirloom seeds are produced on their own three acres farm in Accord; the rest are sourced from other local farmers. Online, you can access over 400 varieties of vegetable, flower or herb seeds. The farm also includes several trial gardens for traditional method breeding experiments. A mission driven business, they use only organic growing methods, and are especially committed to preserving local varieties known as "natives". the HVSL has signed the Safe Seed Pledge and adheres to Vandana Shiva's Declaration of Seed Freedom. Their <a href="http://www.seedlibrary.org/art-packs.html" target="_blank">"Art Packs"</a> designs are selected an annual artists competition.</p>