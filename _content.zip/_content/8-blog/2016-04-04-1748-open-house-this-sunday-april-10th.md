---
title: 'Open House This Sunday - April 10th'
author: HudsonWoods
categories:
  - hudson woods
  - community
  - hudson valley
featuredImage: /assets/img/journal/3-20160404180642.jpg
contentSummary: '<p>We are holding our first Spring open house at Hudson Woods this <span class="aBn" data-term="goog_1809398624" tabindex="0"><span class="aQJ">Sunday, April 10th</span></span> from <span class="aBn" data-term="goog_1809398625" tabindex="0"><span class="aQJ">11:00 AM - 1:00 PM</span></span>. Tour the model home, meet the architect Drew Lang, explore progress on-site, and take a look at the remaining available lots as we prepare them for construction.</p>'
---
<p><img src="/assets/img/journal/resized/3-20160404180542.jpg"></p><p>We are holding our first Spring open house at Hudson Woods this Sunday, April 10th from 11:00 AM - 1:00 PM. Tour the model home, meet the architect Drew Lang, explore progress on-site, and take a look at the remaining available lots as we prepare them for construction.</p><strong>OPEN HOUSE: </strong>Sunday, April 10th | 11:00 AM - 1:00 PM<br style="line-height: 22.4px;"><strong>ADDRESS:</strong> 101 Ridgewood Rd. Kerhonkson NY, 12446<br style="line-height: 22.4px;"><br style="line-height: 22.4px;"><p><a href="https://hudsonwoods.com/availability"><img src="https://hudsonwoods.com/assets/img/journal/resized/View-Availability.jpg" alt=""></a> <a href="https://hudsonwoods.com/contact"><img src="https://hudsonwoods.com/assets/img/journal/resized/Inquire-Here.jpg" alt=""></a><br></p><p><br></p><p><br></p><p><br></p>