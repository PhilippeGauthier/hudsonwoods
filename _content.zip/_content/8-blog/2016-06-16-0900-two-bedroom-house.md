---
title: Two Lots Now Available at $595,000 with 2 Bedroom House
author: HudsonWoods
featuredImage: /assets/img/journal/House-20160616122339.jpg
categories:
  - hudson woods
  - design
  - new release
contentSummary: '<p>A two bedroom house is now available to purchase at Hudson Woods on Lot 02 and Lot 18. The two bedroom house is 1,000 square feet with 370 square feet of covered porch. The home also features two bathrooms, a wood burning stove, full kitchen, cedar siding, decking and soffits and high-efficiency forced air heating and air conditioning. The home is available with the full selection of Hudson Woods upgrades.</p>'
---
<p><img src="/assets/img/journal/resized/2 bed house EDIT 2-20160614142429.jpg" style="line-height: 1.6em;"></p><p>A two bedroom house is now available to purchase at Hudson Woods on Lot 02 and Lot 18. The two bedroom house is 1,000 square feet with 370 square feet of covered porch. The home also features two bathrooms, a wood burning stove, full kitchen, cedar siding, decking and soffits and high-efficiency forced air heating and air conditioning. The home is available with the full selection of Hudson Woods upgrades.<span></span></p><p><img src="/assets/img/journal/resized/2-bdrm-fp.jpg"></p><p><img src="/assets/img/journal/resized/SECTION RENDER.jpg"></p><p><br></p>