---
title: Open House This Sunday With Drew Lang
author: HudsonWoods
categories:
  - open house
  - hudson valley
  - weekend
featuredImage: /assets/img/journal/IMG_5507-20160622170310.jpg
contentSummary: '<p>A friendly reminder that we are holding an open house this Sunday hosted by Architect, Drew Lang. With summer kicking into full gear, it is always refreshing to get away for a bit of that fresh mountain air. Come by to get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p>'
---
<p><img src="/assets/img/journal/resized/IMG_5507.jpg"></p><p><strong>Open House: Sunday, June 26th 12:00 PM - 2:00 PM</strong></p><p>A friendly reminder that we are holding an open house this Sunday hosted by Architect, Drew Lang. With summer kicking into full gear, it is always refreshing to get away for a bit of that fresh mountain air. Come by to get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p><p><img src="/assets/img/journal/resized/IMG_5135.jpg"></p><p><img src="/assets/img/journal/resized/IMG_4905.jpg"></p><p><img src="/assets/img/journal/resized/hw_door-20160622170238.jpg"></p><p><br></p><p><br></p>