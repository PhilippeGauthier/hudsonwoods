---
title: Photo Recap of the Summer Event
author: HudsonWoods
featuredImage: /assets/img/journal/hudsonwoods-4033-20160728111412.jpg
categories:
  - events
  - summer
  - upstate
  - catskills
contentSummary: "<p>We had a great time this past weekend at the Hudson Woods Summer Gathering. Thank you to everyone who joined us and thank you to the makers and designers who took the time to speak about their work. Folks who joined us included Barn & Field, Black Creek Mercantile, Materia Design, Samuel Moyer Furniture, Silk & Willow, Traditions Linens and Wickham Solid Wood Studio. Here is a photo recap of the day's events.</p>"
---
<p><img src="/assets/img/journal/resized/hudsonwoods-4033.jpg" style="line-height: 1.6em;"></p><p>We had a great time this past weekend at the Hudson Woods Summer Gathering. Thank you to everyone who joined us and thank you to the makers and designers who took the time to speak about their work. Folks who joined us included Barn & Field, Black Creek Mercantile, Materia Design, Samuel Moyer Furniture, Silk & Willow, Traditions Linens and Wickham Solid Wood Studio. Here is a photo recap of the day's events:</p><p><img src="/assets/img/journal/resized/hudsonwoods-3164.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3193.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3288.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3401.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3326.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3484.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3420.jpg"><br></p><p><img src="/assets/img/journal/resized/hudsonwoods-3342.jpg"><br></p><p><img src="/assets/img/journal/resized/hudsonwoods-3524.jpg"><br></p><p><img src="/assets/img/journal/resized/hudsonwoods-3404.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3414.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3490.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3586.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3556.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3706.jpg"></p>