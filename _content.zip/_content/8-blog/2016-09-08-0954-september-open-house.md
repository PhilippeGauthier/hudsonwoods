---
title: September Open House Schedule
author: HudsonWoods
categories:
  - hudson valley
  - open house
  - architecture
featuredImage: /assets/img/journal/1-20160908111828.jpg
contentSummary: '<p>Three open houses will be held at Hudson Woods in September. Come by to enjoy the last few weeks summer this year in the mountains. Get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p>'
---
<p><img src="/assets/img/journal/resized/1-20160908111709.jpg" style="line-height: 1.6em;"><br>Photo by <a href="http://www.jamestmurray.com/" target="_blank">James Murray Photography</a><br><span></span><br>
</p><p><strong></strong><strong>Open House Schedule: </strong><br>Sunday, Sep 11th 12:00 PM - 2:00 PM<br>Sunday, Sep 18th 12:00 PM - 2:00 PM<br>Sunday, Sep 25th 12:00 PM - 2:00 PM<span class="redactor-invisible-space"><br></span>
</p><p>Three open houses will be held at Hudson Woods in September. Come by to enjoy the last few weeks summer this year in the mountains. Get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.
</p><p><img src="/assets/img/journal/resized/2-20160908111720.jpg">
</p><p><img src="/assets/img/journal/resized/3-20160908111738.jpg">
</p><p><img src="/assets/img/journal/resized/4-20160908111749.jpg"><br>
</p><p><img src="/assets/img/journal/resized/5-20160908111758.jpg"><br>
</p>