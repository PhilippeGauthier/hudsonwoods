---
title: Underwater Film at the Hudson Woods Pool
author: HudsonWoods
featuredImage: /assets/img/journal/1-20161019170427.jpg
categories:
  - photography
  - hudson valley
  - outdoors
contentSummary: "<p>This past summer, our friend Alice Gao stayed at Hudson Woods and captured a beautiful video centered around the pool with underwater footage. The sunny and warm weather has put us in a bit of a summer mood so we wanted to share her wonderful work. Here are some images and stills from the video and Alice's blog post. </p>"
---
<p><img src="/assets/img/journal/resized/1-20161019155110.jpg"></p><p>This past summer, our friend Alice Gao stayed at Hudson Woods and captured a beautiful video centered around the pool with underwater footage. The sunny and warm weather has put us in a bit of a summer mood so we wanted to share her wonderful work. Here are some images and stills from the video and Alice's blog post. Watch the full video here: <span style="color: rgb(84, 141, 212);"><a href="http://www.hudsonwoods.com/blog/underwater-film"><span style="color: rgb(84, 141, 212);"></span></a><a href="http://www.lingered-upon.com/2016/09/a-moment-with-la-prairie.html" target="_blank"><span style="color: rgb(49, 133, 155);"></span></a><a href="http://www.lingered-upon.com/"><span style="color: rgb(36, 64, 97);"></span></a><a href="http://www.lingered-upon.com/2016/09/a-moment-with-la-prairie.html" target="_blank"><strong><span style="color: rgb(36, 64, 97);"></span></strong></a><strong><a href="http://www.lingered-upon.com">www.lingered-upon.com</a></strong></span><br></p><p><img src="/assets/img/journal/resized/5-20161019155250.jpg"></p><p><img src="/assets/img/journal/resized/3-20161019155300.jpg"></p><p><img src="/assets/img/journal/resized/2-20161019155308.jpg"></p><p><img src="/assets/img/journal/resized/4-20161019155316.jpg"></p><p><img src="/assets/img/journal/resized/6-20161019155324.jpg"></p>