---
title: Open House This Sunday
author: HudsonWoods
featuredImage: /assets/img/journal/Hudson-Woods-Gear-Patrol-Slide-1-20161028112635.jpg
contentSummary: '<p>Architect Drew Lang will hold an open house this Sunday, October 30th from 12-2 PM at the model house. Come by to see the progress on-site. Bring the whole family to enjoy the beautiful autumn days upstate. Only 4 lots remain available for purchase and in November Drew will had two more open houses. Here is the full schedule below. We hope to see you there!</p>'
categories:
  - open house
  - hudson valley
  - autumn
---
<p><img src="/assets/img/journal/resized/Hudson-Woods-Gear-Patrol-Slide-1.jpg"></p><p>Architect Drew Lang will hold an open house this Sunday, October 30th from 12-2 PM at the model house. Come by to see the progress on-site. Bring the whole family to enjoy the beautiful autumn days upstate. Only 4 lots remain available for purchase and in November Drew will had two more open houses. Here is the full schedule below.  We hope to see you there!</p><p><strong>Open House Schedule:</strong><br>Sunday, Oct 30th 12:00 PM - 2:00 PM<br>Sunday, Nov 6th 12:00 PM - 2:00 PM<br>Sunday, Nov 13th 12:00 PM - 2:00 PM<span class="redactor-invisible-space"><br></span></p><p><img src="/assets/img/journal/resized/Hudson-Woods-Gear-Patrol-Slide-4.jpg"></p><p><img src="/assets/img/journal/resized/Hudson-Woods-Gear-Patrol-Slide-14.jpg"></p>