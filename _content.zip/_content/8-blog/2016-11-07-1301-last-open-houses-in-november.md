---
title: Last Open House in November
author: HudsonWoods
featuredImage: /assets/img/journal/1-20161107161957.jpg
contentSummary: '<p>Architect Drew Lang will hold an open house this Sunday, Nov. 13th from 12-2 PM at the model house. Come by to see the progress on-site. Bring the whole family to enjoy the beautiful autumn days upstate. Only 4 lots remain available for purchase. We hope to see you there!</p>'
---
<p><img src="/assets/img/journal/resized/Lead-20161107132425.png"></p><p>Architect Drew Lang will hold an open house this Sunday, Nov. 13th from 12-2 PM at the model house. Come by to see the progress on-site. Bring the whole family to enjoy the beautiful autumn days upstate. Only 4 lots remain available for purchase. We hope to see you there!</p><p><img src="/assets/img/journal/resized/1-20161107132435.png"></p><p><img src="/assets/img/journal/resized/5-20161107161927.jpg"></p>