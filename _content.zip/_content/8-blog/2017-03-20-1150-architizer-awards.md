---
title: Vote for Hudson Woods in the Architizer A+ Awards
author: HudsonWoods
categories:
  - architizer
  - architecture
  - design
  - awards
featuredImage: /assets/img/journal/4-20170320120655.jpg
contentSummary: '<p>Hudson Woods has been selected as a finalist for the A+ Awards and you can help us become the winner! We are in the Mulit-Unit Low Rise (1-4) Housing category. In order to vote, go to the link below and enter the category name into the search bar.  </p><p><br></p>'
---
<p><img src="/assets/img/journal/resized/1-20170320120634.jpg"></p><p><br>Hudson Woods has been selected as a finalist for the A+ Awards and you can help us become the winner! We are in the Mulit-Unit Low Rise (1-4) Housing category. In order to vote, go to the link below and enter the category name into the search bar.<span class="redactor-invisible-space" style="background-color: initial;"> </span><strong><a href="https://vote.architizer.com/PublicVoting#/winners/2017/typology/residential/multi-unit-housing-low-rise-1-4-floors" target="_blank">Click Here to Vote</a></strong></p><p><img src="/assets/img/journal/resized/x1-20170320120305.jpg"></p><p><img src="/assets/img/journal/resized/x2-20170320120318.jpg"></p><p><img src="/assets/img/journal/resized/x3.jpg"></p>