---
title: Saturday Open House + 3 Great Hikes Upstate
author: HudsonWoods
categories:
  - outdoors
  - hudson valley
  - catskills
featuredImage: /assets/img/journal/2-20160610123228.jpg
contentSummary: |
  <p>With Spring in full swing and summer around the corner, the time of year is here again to hit some of the best hiking trails the Hudson Valley has to offer. Our friends at <a href="http://www.visitvortex.com/magazine/spring-2016-leave-no-trace" target="_blank">Visit Vortex</a> assembled 3 great videos of their favorite hikes in the area, which can be seen here below. We will also be holding an <strong>open house</strong> next Sunday, June 4th, from <strong>12:00 PM - 2:00 PM</strong>. We hope you can stop by.
  </p>
---
<p><img src="/assets/img/journal/resized/2-20160610123222.jpg">
</p><p>With Spring in full swing and summer around the corner, the time of year is here again to hit some of the best hiking trails the Hudson Valley has to offer. Our friends at <a href="http://www.visitvortex.com/magazine/spring-2016-leave-no-trace" target="_blank">Visit Vortex</a> assembled 3 great videos of their favorite hikes in the area, which can be seen here below. We also hope you can stop by our open house next weekend, with details below. </p><p><strong>Open House<br></strong><strong>Saturday, June 3rd | 12:00 PM - 2:00 PM<br>101 Ridgewood Rd. Kerhonkson, NY 12446<br><br></strong></p><p>
	<iframe width="560" height="315" src="https://www.youtube.com/embed/MwviRh19ffs" frameborder="0" allowfullscreen="">
	</iframe><br>
</p><p>
	<iframe width="560" height="315" src="https://www.youtube.com/embed/tIq5LUoWxjQ" frameborder="0" allowfullscreen="">
	</iframe><br>
</p><p>
	<iframe width="560" height="315" src="https://www.youtube.com/embed/hsloxcTmuDY" frameborder="0" allowfullscreen="">
	</iframe><br>
</p>