---
title: 7 Interesting Real Estate Insights About The Hudson Valley
author: HudsonWoods
featuredImage: /assets/img/journal/18HUDSON1-superJumbo-20170622173644.jpg
categories:
  - real estate
  - hudson valley
  - architecture
contentSummary: |
  <p>Last weekend, Hudson Woods was featured in a New York Times article. Among a number of interesting insights, there were a number of facts about the burgeoning local real estate market which stood out. We thought it would be interesting to share some of these insights along with photos from the feature and a link to the rest of the article.
  </p>
---
<p><img src="/assets/img/journal/resized/18HUDSON1-superJumbo.jpg"><br><span style="color: rgb(127, 127, 127);">Tony Cenicola/The New York Times</span><span style="color: rgb(127, 127, 127);"></span><br>
</p><p>Last weekend, we were thrilled to see an article published in The New York Times about Hudson Woods. Among a number of interesting insights, there were several stand out facts about the burgeoning local real estate market and how Hudson Woods fits into the larger picture. We thought it would be interesting to share some of these insights along with photos from the feature and <strong> <a href="https://www.nytimes.com/2017/06/16/realestate/hudson-valley-homes-upstate-new-york.html" target="_blank">a link to the rest of the article</a></strong>.
</p><p>Plus, stop by our open house this Sunday.<br>Hosted by Architect, Drew Lang from 12-2 PM.<br>101 Ridgewood Rd. Kerhonkson, NY 12446
</p><p><strong><u>7 Interesting Real Estate Insights About The Hudson Valley</u></strong></p><p>1) In Q1 of 2017, in Ulster County, there was an 18% increase of total homes<br>sold compared with the same time period if 2014.
</p><p>2) In Q1 of 2017, in Columbia County, there was a 45% increase of total homes<br>sold compared with the same time period if 2014.</p><p>3) In Q1 of 2017<span class="redactor-invisible-space">,</span> in Dutchess County, there was a 114%% increase of total homes<br>sold compared with the same time period if 2014.</p><p>4) In Q1 of 2017, in Ulster County,<span class="redactor-invisible-space"> the average price of sold homes<br>increased by 3.6% percent over the same time period in 2016.<br></span></p><p>5) In 2016, in Ulster County, there was a 16% increase of total homes sold compared to 2015.<br>In 2016, in Ulster County, the average price of homes sold also increased by 1.7% percent over 2015.</p><p>6) In the past 6 months in Ulster County, there have been three record-breaking sales of around $3 million.</p><p>7) Since 2012, Ulster County has seen record year followed by record year in home sales.<br><br></p><p><strong></strong>
</p><p><img src="/assets/img/journal/resized/18HUDSON2-superJumbo.jpg"><br>Tony Cenicola/The New York Times<br>
</p><p><img src="/assets/img/journal/resized/18HUDSON3-master675.jpg"><br>Tony Cenicola/The New York Times<br>
</p><p><span></span>
</p>