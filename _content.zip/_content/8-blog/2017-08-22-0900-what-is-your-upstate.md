---
title: ' What is your Upstate?'
author: HudsonWoods
featuredImage: /assets/img/journal/Untitled-2-20170822101610.png
categories:
  - hudson valley
  - upstate
  - new york
contentSummary: '<p>This weeks New Yorker cover story is titled "UPSTATE." Illustrated by author and artist  Adrian Tomine.</p>'
---
<p><br><img src="/assets/img/journal/resized/Untitled-1-20170821183506.png"></p>