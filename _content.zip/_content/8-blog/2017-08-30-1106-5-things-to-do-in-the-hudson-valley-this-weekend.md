---
title: 5 Things to do in the Hudson Valley This Weekend
author: HudsonWoods
featuredImage: /assets/img/journal/Ruins-of-Bannermans-Castle.jpg
categories:
  - hudson valley
  - community
  - in the area
contentSummary: '<p>We highlight 5 places to visit in the Hudson Valley including Bannerman Castle, Basilica Hudson, Bard College and the Fisher Center for the Performing, Bonticou Crag, and the Saugerties Lighthouse.</p>'
---
<p><img src="/assets/img/journal/resized/Ruins-of-Bannermans-Castle-20170818110956.jpg">
</p><p><strong>Bannerman Castle</strong><span class="redactor-invisible-space"><strong>: </strong></span>Tucked into Pollepel Island in the middle of the Hudson River are the stunning and sprawling remnants of Bannerman Castle. In 1900 Francis Bannerman VI purchased Pollepel Island and designed the castle to warehouse stock for his business which bought and sold surplus military equipment of the American Civil War. Today, the island and castle serve as a museum. Currently, you can find an installation by Melissa McGill called “Constellation.”<br><br></p><p><img src="/assets/img/journal/resized/653879.jpg">
</p><p><strong>Bonticou Crag</strong><strong>: </strong><span class="redactor-invisible-space">Bonticou Crag is a six mile rock scramble located in the Mohonk Preserve. It offers clear views of the area, an enjoyable weekend hike and one of the best photo moments in the Hudson Valley.<span class="redactor-invisible-space"><br></span></span><br>
</p><p><img src="/assets/img/journal/resized/saugerties_dinner_000.jpg">
</p><p><strong>Saugerties Lighthouse</strong><strong>: </strong>A landmark beacon on the Hudson River, the Saugerties Lighthouse is a venerable aid to navigation, constructed in 1869 at the mouth of the Esopus Creek. The restored, red-brick Lighthouse offers overnight Bed & Breakfast accommodations, public tours and special event.<span class="redactor-invisible-space"><br><br></span>
</p><p><img src="/assets/img/journal/resized/247.jpg">
</p><p><strong>Basilica Hudson</strong><span class="redactor-invisible-space"><strong>:</strong></span> Located in a solar-powered reclaimed 1880s industrial factory on the waterfront of Hudson, NY, Basilica Hudson is a non-profit multidisciplinary arts center that hosts events such as the Back Gallery Art Series, Non-Fiction movie screenings, and Farm & Flea holiday market. Their mission is to support the creation, production and presentation of arts and culture while fostering sustainable community. <br><br>
</p><p><img src="/assets/img/journal/resized/collegebard.jpg">
</p><p><strong>Bard College / Fisher Center for the Performing</strong><span class="redactor-invisible-space"><strong>: </strong></span>Located in the bustling town of Red Hook, Bard College has a beautiful campus that hosts a variety of events best known for the Bard Music Festival. A popular target for photo-takers is the Fisher Center designed by architect Frank Gehry, who also designed things like the Guggenheim Museum and the EMP museum in Seattle.</p><p><br><br>
</p>