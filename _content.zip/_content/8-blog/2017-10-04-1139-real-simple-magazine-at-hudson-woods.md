---
title: Real Simple Magazine at Hudson Woods
author: HudsonWoods
categories:
  - news
  - press
  - photography
featuredImage: /assets/img/journal/Lead.JPG
contentSummary: '<p>For their October issue, Real Simple Magazine needed a secluded but beautiful mountain retreat where they could shoot a piece on fall outerwear for this season. They found the perfect location in Hudson Woods and we were happy to host them for the shoot. Below we share the results that were published in the magazine which is on shelves now. Fashion Editor Rebecca Daly and photographer Mei Tao directed the shoot. </p>'
---
<p><img src="/assets/img/journal/resized/Lead-700.jpg"></p><p>For their October issue, Real Simple Magazine needed a secluded but beautiful mountain retreat where they could shoot a piece on fall outerwear for this season. They found the perfect location in Hudson Woods and we were happy to host them for the shoot. "The modern designed home sits harmoniously in the wild nature. I love how the property is landscaped. So many available angles to consider for making beautiful imagery," said photographer Mei Tao. </p><p>Fashion Editor, Rebecca Daly also commented, "The ruggedness of the Hudson Valley coupled with Hudson Woods' sleek architecture made it the perfect setting for our story, but on a selfish note, my favorite part of the day was our lunch break -- when we got to sit and eat in gorgeous kitchen and have a moment to take in all the thoughtful details." Below we share the results that were published in the magazine which is on shelves now.</p><p><strong>Plus stop by our Open House</strong>:<br><g>Sunday</g> October 15th | 12-2 PM<br>101 Ridgewood Road<br>Kerhonkson, NY 12446<br><br></p><p><img src="/assets/img/journal/resized/RS1.jpg"></p><p><img src="/assets/img/journal/resized/RS2-700.jpg"></p><p><img src="/assets/img/journal/resized/RS3-700.jpg"></p>