---
title: 'New York Today: A Quest to Define ‘Upstate’'
author: HudsonWoods
featuredImage: /assets/img/journal/29nytoday1-superJumbo.jpg
categories:
  - upstate
  - new york
  - hudson valley
contentSummary: '<p>At what point along the 300-mile journey from New York City to the Canadian border would you consider yourself “upstate”? That is the question that the New York Times hopes to answer in their latest article about the area.</p>'
buttons: ""
---
<p><img src="/assets/img/journal/resized/29nytoday1-superJumbo-20171129183152.jpg"></p><p>At what point along the 300-mile journey from New York City to the Canadian border would you consider yourself “upstate”? That is the question that the New York Times hopes to answer in their latest article about the area.<br></p><p><a href="https://mobile.nytimes.com/2017/11/29/nyregion/new-york-today-a-quest-to-define-upstate.html?referer=" target="_blank">Read the Fill Article Here</a></p>