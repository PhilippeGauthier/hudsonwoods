---
title: 'On The Market: Lot 02 Re-Sale At Hudson Woods'
author: HudsonWoods
featuredImage: /assets/img/journal/8-20180418150325.jpg
buttons: ""
categories:
  - real estate
  - architecture
  - re-sale
contentSummary: '<p>13 Blue Spruce Lan. at Hudson Woods is now available for purchase. The home is lightly used and includes a upgrades such as the wood burning stove and kitchen island. The home has the traditional lower level entry layout with floor-to-ceiling windows in the great room and vaulted ceilings upstairs. </p>'
---
<p><img src="https://hudsonwoods.com/assets/img/journal/resized/8-20180418104927.jpg">
</p><p><br>13 Blue Spruce Lane at Hudson Woods is now available for purchase directly from the house owner. The home was just completed and is unused.  House upgrades include the wood burning stove, kitchen island, radiant heat throughout and the complete Hudson Woods model house decorative lighting package.  The home has a lower level entry layout with floor-to-ceiling windows in the great room and vaulted ceilings upstairs.
</p><p>For more information and to see the home, contact Eric Paskin at eric@potentialllc.com
</p><p><br>
</p><p><img src="/assets/img/journal/resized/2-20180418104848.jpg">
</p><p><img src="/assets/img/journal/resized/3-20180418104854.jpg">
</p><p><img src="/assets/img/journal/resized/4-20180418104900.jpg">
</p><p><img src="/assets/img/journal/resized/6-20180418104907.jpg">
</p><p><img src="/assets/img/journal/resized/7-20180418104913.jpg">
</p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/1-20180418104840.jpg"><br>
</p>