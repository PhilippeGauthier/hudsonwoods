---
title: How to License a Hudson Woods Design
author: HudsonWoods
featuredImage: /assets/img/journal/2-20180509112015.jpg
categories:
  - architecture
  - construction
  - real estate
contentSummary: '<p>Many of you have made inquiries in past months about licensing the Hudson Woods design to build on your own property. We are excited to announce that a Hudson Woods design license is now available for purchase.</p>'
buttons:
  - 
    button_text: See License Details
    button_url: https://hudsonwoods.com/license
    button_file: ""
---
<p><img src="/assets/img/journal/resized/HW-20180509112038.jpg"></p><p>Many of you have made inquiries in past months about licensing the Hudson Woods design to build on your own property. We are excited to announce that a Hudson Woods design license is now available for purchase. You can learn more about how the licensing process works on our licensing page here: <a href="https://hudsonwoods.com/license" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://hudsonwoods.com/license&source=gmail&ust=1525984648659000&usg=AFQjCNHtPx1I3_t-M1lS0d8SFwMZOwSRiQ">https://hudsonwoods.com/<wbr>license</a> and contact us with any questions at <a href="mailto:sales@hudsonwoods.com" target="_blank">sales@hudsonwoods.com</a> </p><p><img src="/assets/img/journal/resized/4-20180509112054.jpg"></p><p><img src="/assets/img/journal/resized/10-20151001110025-20180509112046.jpg"></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0341-20180509112102.jpg"></p><p><img src="/assets/img/journal/resized/9-20151001110039-20180509112105.jpg"></p><p><img src="/assets/img/journal/resized/_DSC8167.1-20180509112112.jpg"></p><p><img src="/assets/img/journal/resized/_DSC7684.1-20180509112122.jpg"></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0911.jpg"></p><p><img src="/assets/img/journal/resized/image1.jpeg"></p><p><img src="/assets/img/journal/resized/unnamed2-20180509112145.jpg"></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0937-20180509112155.jpg"></p>