---
title: 'From the Source: Savarin and Company'
author: HudsonWoods
featuredImage: /assets/img/journal/hw6-20180605102724.jpg
contentSummary: '<p>Our friends at Savarin are Hudson Valley based creatives who wanted to pursue the simple idea that the American flag can be presented as a work of art. They set out to recreate the flag with a meticulous eye for the finer details in a way that it could exist in any home and compliment any interior.<br></p>'
buttons: ""
categories:
  - community
  - hudson valley
  - local made
  - craftsmanship
---
<p><img src="/assets/img/journal/resized/hw6.jpg"></p><p><br>Our friends at <a href="https://www.savarin.co/" target="_blank">Savarin</a> are Hudson Valley based creatives who wanted to pursue the simple idea that the American flag can be presented as a work of art. They set out to recreate the flag with a meticulous eye for the finer details in a way that it could exist in any home and compliment any interior. They also extended their manufacturing to small pennants representing the community and towns that make up the Hudson Valley as well as custom designs.</p><p>All of their materials are made and sourced in the U.S. including Woolrich located in Woolrich, PA. Established in 1830, Woolrich is the longest continually operating woolen mill in the U.S. Savarin's leather work is sourced from Horween Leather Co. in Chicago.(est 1905) and the copper rivets are made by C.S. Osborne (est. 1826) in Harrison, NJ. For his t-shirts the organic grown cotton hails from Shamrock, TX. from a manufacturer called S.O.S. Texas from Shamrock, TX. U.S. Organic grown and made cotton t-shirts.<br><br> </p><p><img src="/assets/img/journal/resized/hw3.jpg"></p><p><img src="/assets/img/journal/resized/hw4.jpg"></p><p><img src="/assets/img/journal/resized/hw5.jpg"></p><p><img src="/assets/img/journal/resized/hw2.jpg"></p><p><img src="/assets/img/journal/resized/hw1.jpg"></p>