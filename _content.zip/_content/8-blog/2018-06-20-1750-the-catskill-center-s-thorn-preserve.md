---
title: "The Catskill Center's Thorn Preserve"
author: HudsonWoods
featuredImage: /assets/img/journal/Lead-20180612125828.jpg
buttons: ""
categories:
  - catskills
  - hudson valley
  - community
  - nature
contentSummary: '<p>The Catskill Center is a wonderful organization dedicated protecting and fostering the environmental, cultural and economic well-being of the Catskill Region. Since 1969 they have led the effort to protect more than 700,000 acres of the catskill park and forest preserve.<br></p>'
---
<p><img src="/assets/img/journal/resized/2-20180612125837.JPG"></p><br><a href="http://catskillcenter.org/" target="_blank">The Catskill Center</a> is a wonderful organization dedicated protecting and fostering the environmental, cultural and economic well-being of the Catskill Region. Since 1969 they have led the effort to protect more than 700,000 acres of the catskill park and forest preserve.<p><span></span></p><p>Their latest effort is the <a href="http://catskillcenter.org/thorn-preserve/" target="_blank">Thorn Preserve</a>, comprised of 60 beautiful acres minutes from the Town of Woodstock, Ulster County and a scenic 20 mile drive from Hudson Woods through Phoenicia and the Ashokan Reservoir. </p><p>The preserve boasts the most painted views of Overlook Mountain. Sweeping grassland habitat, riparian forest and ponds make this spot a profoundly relaxing and peaceful area and mowed walking paths are easily accessible. The Preserve will remain an undeveloped landscape, which will allow them to offer nature-based education, sustainable agriculture, model stream management, and an ideal artists’ retreat.<br><br></p><p><span></span></p><p><img src="/assets/img/journal/resized/4-20180612125850.JPG"></p><p><img src="/assets/img/journal/resized/3-20180612125859.JPG"></p><p><img src="/assets/img/journal/resized/6-20180612125907.JPG"></p><p><img src="/assets/img/journal/resized/1-20180612125927.jpg"><br><br></p>