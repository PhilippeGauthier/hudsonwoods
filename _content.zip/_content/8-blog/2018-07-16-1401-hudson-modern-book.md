---
title: Hudson Modern Book Features Hudson Woods
author: HudsonWoods
categories:
  - architecture
  - book
  - hudson valley
featuredImage: /assets/img/journal/IMG_2267.JPG
buttons: ""
contentSummary: '<p>Hudson Modern is a recently released book which showcases stunning new houses in the Hudson River Valley that embrace the dramatic settings and cultural bounty of this popular region.</p>'
---
<p><img src="/assets/img/journal/resized/IMG_2071-20180716111448.JPG"></p><p><br>Hudson Modern is a recently released book which showcases stunning new houses in the Hudson River Valley that embrace the dramatic settings and cultural bounty of this popular region.</p><p>As the birthplace of American landscape painting, the Hudson River Valley has long been a refuge from the city and a laboratory for new aesthetic expression. Today, thanks to its ascendant reputation as a weekend utopia, architects are extending that tradition into the built environment. Designing residences that revere local climate, landscape, and history in a distinctly modernist language, these talents are sowing a new Hudson River school of architectural thought. </p><p>The book features a conversation with Drew Lang, Lead Architect of Hudson Woods and Principal at Lang Architecture. The conversation centers around why the project is located in the Hudson Valley, what inspired the project and design process and number of other topics. </p><p>You can learn more about the book here: <a href="http://www.monacellipress.com/book/?isbn=9781580934848" target="_blank">Hudson Modern | Residential Landscapes</a><br><br></p><p><img src="/assets/img/journal/resized/IMG_2074.JPG"></p><p><img src="/assets/img/journal/resized/IMG_2075.JPG"></p><p><img src="/assets/img/journal/resized/IMG_2076.JPG"></p>