---
title: Open Source Institute Opens River-to-Ridge
author: HudsonWoods
categories:
  - hudson woods
  - community
  - protected lands
  - nature trails
featuredImage: /assets/img/journal/005.jpg
contentSummary: |
  <p>In September
  2018, the Open Space Institute opened the River-to-Ridge Trail. Opening
  celebrations of the six-mile loop trail brought in over 300 people.</p>
buttons: ""
---
<p><img src="/assets/img/journal/003.jpg" alt="003.jpg"></p><p>In September 2018, the Open Space Institute opened the River-to-Ridge Trail. Opening celebrations of the six-mile loop trail brought in over 300 people.</p>  <p>The new trail traverses land conserved by OSI, connecting New Paltz directly to Minnewaska and Mohonk, creating access to the people of New Paltz to more than 90 miles of trails and carriage roads.</p>  <p>The new trail is an example of how protected land safeguards natural and cultural resources, at the same time providing terrific recreational opportunities while strengthening community and the local economy.<br><br>To learn more about the River-to-Ridge Trail, check out the Open Space Institute's page <a href="https://www.openspaceinstitute.org/news/river-to-ridge-trail-grand-opening-video" target="_blank">here</a>.</p><p><img src="/assets/img/journal/resized/002.jpg"></p><p><img src="/assets/img/journal/006.jpg" alt="006.jpg"></p>