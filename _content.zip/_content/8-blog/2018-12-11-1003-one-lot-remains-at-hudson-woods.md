---
title: 'On The Market - Hudson Woods Model House'
author: HudsonWoods
featuredImage: /assets/img/journal/4-20181211171048.jpg
contentSummary: '<p>We are excited to announce that lot 07 remains the last available lot at Hudson Woods. This is the first Hudson Woods house constructed and it was held by us for the duration of the project. The house is furnished and appointed by our team and includes augmentations above and beyond many of the other Hudson Woods houses, including substantial landscaping work that has matured, a custom planter and firepit installation, a custom laundry room and other built-in shelving around the house, shades on select windows, etc.<span class="redactor-invisible-space"></span></p>'
buttons:
  - 
    button_text: 'View Lot 07 Details '
    button_url: https://hudsonwoods.com/availability/for-sale/lot-07
    button_file: ""
categories:
  - hudson woods
  - upstate
  - catskills
  - from the source
  - sustainable
  - moment
  - nature
  - architecture
---
<p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/HW-20181211171110.jpg" alt="" "=""></a></p><p>We are excited to announce that lot 07 remains the last available lot at Hudson Woods. This is the first Hudson Woods house constructed and it was held by us for the duration of the project. The house is furnished and appointed by our team and includes augmentations above and beyond many of the other Hudson Woods houses, including substantial landscaping work that has matured, a custom planter and firepit installation, a custom laundry room and other built-in shelving around the house, shades on select windows, etc.</p><p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/_DSC8167.1-20181211171210.jpg" alt="" "=""></a></p><p>Only 3 years after launch, more than half of the homes are now completed with the remainder in various stages of construction. In the midst of the Hudson River Valley and just two hours from New York City, Hudson Woods is an experience that opens doors to discovering the things that matter.</p><p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/_DSC7840.1-20181211171258.jpg" alt="" "=""></a></p><p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/_DSC8105.1.jpg" alt="" "=""></a><br></p><p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/_DSC8187.1.jpg" alt="" "=""></a></p><p><a href="https://hudsonwoods.com/availability/for-sale/lot-07"><img src="/assets/img/journal/resized/_DSC7934.1.jpg" alt="" "=""></a></p><p><br></p>