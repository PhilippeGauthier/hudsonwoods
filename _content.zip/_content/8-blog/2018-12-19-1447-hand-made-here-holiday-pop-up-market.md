---
title: Hand Made Here, Holiday Pop Up Market
author: HudsonWoods
featuredImage: /assets/img/journal/Grid-Clean.jpg
contentSummary: '<p>Still have some holiday shopping left to do?</p><p>There’s still plenty of time to find that perfect gift while supporting Hudson Valley’s local makers and artisans. Open everyday from now till Christmas Eve, the Hand Made Here holiday pop up shop offers a selection of goods from 40+ artists and makers from around the Hudson Valley region.</p>'
buttons: ""
categories:
  - handmade
  - artisanal
  - pop-up market
  - hudson valley
---
<p><img src="/assets/img/journal/resized/Grid-Clean-20181219145817.jpg"></p><p>Still have some holiday shopping left to do?</p>  <p>There’s still plenty of time to find that perfect gift while supporting Hudson Valley’s local makers and artisans. Open everyday from now till Christmas Eve, the Hand Made Here holiday pop up shop offers a selection of goods from 40+ artists and makers from around the Hudson Valley region. Put on by the Hudson River Exchange and collaborating with Drop Forge & Tool, this year shoppers are able to shop at two locations in the vibrant and historic Hudson Valley downtown on Warren Street.</p><p><img src="/assets/img/journal/resized/mug-20181219150455.JPG"></p>  <p>Featuring the best handmade gifts, from home furnishings, ceramics, jewelry, children’s toys, specialty foods, all natural beauty products and more! Prices range from $5 to $500 with most prices falling under $50. Stop by the Hudson River Exchange at 514 Warren Street or visit at Drop Forge & Tool at 442 Warren Street to check out the selection.</p>  <p>Visit Drop Forge & Tool on December 19<sup>th</sup>, from 6:00PM-8:00PM for the last night of their holiday handcraft series making stringed popcorn and cranberry garland. Materials will be supplied, but feel free to bring your own items to string. Suggested donations are $5.</p><p><img src="/assets/img/journal/resized/quilt-20181219150129.JPG"></p><p><img src="/assets/img/journal/resized/Carsel Newsletter Image.JPG"><br></p><p><img src="/assets/img/journal/resized/DSC_0101.jpg"></p><p><img src="/assets/img/journal/resized/image-7_1080x-20181219150522.jpg"><br></p><p><br></p>