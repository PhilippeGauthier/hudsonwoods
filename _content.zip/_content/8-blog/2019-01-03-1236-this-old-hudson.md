---
title: This Old Hudson
author: HudsonWoods
featuredImage: /assets/img/journal/7.+entryway.jpg
contentSummary: '<p>This Old Hudson is a multifunctional creative studio available for bookings. A destination for creativity, photography, lodging, intimate gatherings, a weekend retreat… the opportunities that can be unlocked in the space are near endless.</p>'
buttons: ""
categories:
  - hudson valley
  - creative studio
  - retreat
  - local artists
  - rental space
---
<p><img src="/assets/img/journal/resized/7.+entryway-20190103123840.jpg"></p><p>This Old Hudson is a multifunctional creative studio available for bookings. A destination for creativity, photography, lodging, intimate gatherings, a weekend retreat… the opportunities that can be unlocked in the space are near endless.</p>  <p>The studio space is the brain child of Anthony D’Argenzio, the founder of Zio and Sons, a New York Creative & Styling brand. Two units are available for booking in the two-story 1910 house located right off the main drag in Hudson, New York.</p>  <p>Curated with local finds from antique stores in and around the Hudson, the elegant eclectic rooms are redefined by the simplicity of the plaster and marble construction materials, and the warmly layered, character-ful furnishings that Anthony refers to as “a high-end look on a budget” and “a study in 50 shades of weathered white”.</p><p><img src="/assets/img/journal/resized/Anthony+Zio_0006.jpg"></p><p><img src="/assets/img/journal/resized/Anthony+Zio_0002.jpg"></p><p><img src="/assets/img/journal/resized/6.+bathroom+1+.jpg"></p><p><img src="/assets/img/journal/resized/1.+kitchen+-+horizontal.jpg"></p><p><img src="/assets/img/journal/resized/Anthony+Zio_0007.jpg"><br></p>