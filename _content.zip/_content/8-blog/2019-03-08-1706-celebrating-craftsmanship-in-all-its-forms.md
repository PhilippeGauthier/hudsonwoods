---
title: Celebrating Craftsmanship In All Its Forms
author: HudsonWoods
featuredImage: /assets/img/journal/Thornwillow+Les+Ateliers+Courbet-20190308171346.jpg
buttons: ""
contentSummary: '<p>Celebrate the art of craftsmanship and the printed word with a visit to the Thornwillow Press Institute in Newburgh, New York.  Founded in 2015 by Luke Ives Pontifell, to promote and perpetuate the art of craftsmanship in all its forms – the former coat factory now houses centuries of antique printing equipment, while continuing to publish original works by leading thinkers and artists, keeping the traditions and techniques of the book arts alive.</p>'
categories:
  - community, hudson valley, local made, craftsmanship
---
<p><img src="/assets/img/journal/resized/Thornwillow+Les+Ateliers+Courbet.jpg"></p><p>Celebrate the art of craftsmanship and the printed word with a visit to the Thornwillow Press Institute in Newburgh, New York.Founded in 2015 by Luke Ives Pontifell, to promote and perpetuate the art of craftsmanship in all its forms – the former coat factory now houses centuries of antique printing equipment and continues to publish original works by leading thinkers and artists while keeping the traditions and techniques of the book arts alive.</p><p><strong><a href="https://www.thornwillowinstitute.org/events-2" target="_blank">View Upcoming Events at Thornwillow Institute</a></strong></p><p><br></p><p><img src="/assets/img/journal/resized/Side+of+building.jpg"><span class="redactor-invisible-space"><br></span></p><p><br></p><hr><p><i>“Ultimately, what we do is
a very simple thing.  It's black ink on white paper, and from that very
simple combination, one can open up visions of the universe."  - Luke Ives Pontifell</i><br></p><hr><p><br></p><p><img src="/assets/img/journal/resized/books_dsc_3105-Christine Ashburn-2.jpg"></p><p><br></p><p><img src="/assets/img/journal/resized/books_dsc_3544-3.jpg"></p><p><br></p>