---
title: 'Hudson Woods Partners - M. Teixeira Soapstone'
author: HudsonWoods
featuredImage: /assets/img/journal/sopastone-kitchen.gif
buttons: ""
---
<p><img src="/assets/img/journal/resized/Teixeira-20190605145934.jpg"></p><p>We continue to express our appreciation to our partners whose products helped us define and shape the uniqueness of each home at Hudson Woods. The next Hudson Woods Partner we want to call attention to is our friend Rogerio M. Teixeira, owner of <a data-cke-saved-href="https://www.soapstones.com/" href="https://www.soapstones.com/" target="_blank">M. Teixeira Soapstone</a>. We love his Anastacia soapstone slabs, used for kitchen and island counter-tops at the Hudson Woods homes. These unique pieces bring heritage from another part of the globe into the homes - an exotic, yet warm and familiar touch.
</p><p><br>
</p><p align="center"><a href="https://hudsonwoods.com/assets/img/journal/Texeira%20soapstone%20spread.pdf">DOWNLOAD SPECIFICATION</a>
<br>
</p><p><br>
</p>