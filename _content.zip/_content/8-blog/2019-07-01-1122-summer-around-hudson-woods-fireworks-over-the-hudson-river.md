---
title: 'Summer Around Hudson Woods: Fireworks Over The Hudson River'
author: HudsonWoods
featuredImage: /assets/img/journal/ISP_0264.jpg
buttons: ""
---
<p><img src="/assets/img/journal/resized/ISP_0264-20190701114158.jpg"></p><p>4<sup>th</sup> of July is around the corner and nothing quite like watching fireworks boom among the stars after a day of firing up that barbecue and lounging by the pool with loved ones. There are plenty of celebrations and parades in towns around Hudson Woods and when the night comes head down to The City of Poughkeepsie for its spectacular fireworks.</p><p>The best view to watch is from 212 feet above the Hudson River on the Walkway over the Hudson State Historic Park, the world’s longest elevated pedestrian bridge. The walkway will reopen at 7 pm and the fireworks will begin around 9 pm. Get your tickets <a href="https://walkway.z2systems.com/np/clients/walkway/eventRegistration.jsp?event=380&">here</a> as they are selling fast.</p><p>For complete event information, visit <a href="https://walkway.org/4th-of-july-fireworks-spectacular/">walkway.org/fireworks</a></p><p>Happy 4th of July!</p><p>Photo credit: walkway.org</p>