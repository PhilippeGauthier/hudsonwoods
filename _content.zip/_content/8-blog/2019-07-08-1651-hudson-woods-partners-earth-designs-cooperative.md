---
title: 'Hudson Woods Partners - Earth Designs Cooperative'
author: HudsonWoods
featuredImage: /assets/img/journal/Instagram_1080x1080_012.jpg
buttons: ""
---
<p><img src="/assets/img/journal/resized/EARTH DESIGNS Aja white-20190708190617.jpg"></p><p>We continue to express our appreciation to our partners whose products helped us define and shape the uniqueness of each home at Hudson Woods. The next Hudson Woods Partner we want to call attention to is Earth Designs Cooperative. Founded by Aja Hudson in 2001 and now transitioned to a worker-owned cooperative, Earth Designs' vision is foster meaningful connections between people and plants through the creation of unique installations, woodland plantings, native meadows, and vegetable and medicinal gardens. Because of these shared values, we turned to Earth Designs for their ability to enhance the raw beauty of the Hudson valley landscape rather than attempt to modify it.</p><p align="center"><a href="https://hudsonwoods.com/assets/img/journal/earth%20designs%20spread.pdf" target="_blank">DOWNLOAD SPECIFICATION</a></p>