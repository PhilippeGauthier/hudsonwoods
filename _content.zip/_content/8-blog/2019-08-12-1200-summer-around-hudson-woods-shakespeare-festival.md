---
title: 'Summer Around Hudson Woods: Shakespeare Festival'
author: HudsonWoods
featuredImage: /assets/img/journal/Tent-Wide-Shot-e1525194131296.jpg
buttons: ""
---
<p><img src="/assets/img/journal/resized/Tent-Wide-Shot-e1525194131296-20190722153547.jpg"><br></p><p>It’s always tough to decide which shows to catch at any new
summer season of the Hudson Valley Shakespeare Festival. Between Much Ado About
Nothing and Cymbeline plus two by other authors, the festival’s open air Theater
Tent is the perfect home for the sorts of comical-tragedy hybrids. Catch these
plays before it ends on September 8<sup>th</sup>, 2019 at the Boscobel’s Great
Lawn in Garrison, NY. For more information, visit: <a href="https://hvshakespeare.org/" target="_blank">hvshakespeare.org</a></p>