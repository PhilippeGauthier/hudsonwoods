---
title: 'Open House at Hudson Woods: Feb 2nd'
author: HudsonWoods
categories:
  - snow
  - skiing
  - winter
  - hudson valley
  - open house
  - architect
featuredImage: /assets/img/journal/Open-House-Lead.jpg
contentSummary: '<p>All are welcome to visit the Hudson Woods model home Sunday, February 2nd, from 12:00pm - 3:00pm, as we open our doors to the public!</p>'
buttons:
  - 
    button_text: Last Home For Sale
    button_url: https://hudsonwoods.com/availability
    button_file: ""
---
<p><img src="/assets/img/journal/resized/Open-House-Lead-20200129110035.jpg"></p><p>All are welcome to visit the Hudson Woods model home Sunday, February 2nd, from 12:00pm - 3:00pm, as we open our doors to the public!</p><p><br>Drew Lang, the project architect and developer, will be present to field questions about purchasing this house, the final Hudson Woods home.</p><p><br><strong>Visit us at <a data-cke-saved-href="https://www.google.com/maps/place/101+Ridgewood+Rd,+Kerhonkson,+NY+12446/@41.8887052,-74.313213,17z/data=!3m1!4b1!4m5!3m4!1s0x89dce387ed71485b:0xcacbdba473583f26!8m2!3d41.8887052!4d-74.3110243" href="https://www.google.com/maps/place/101+Ridgewood+Rd,+Kerhonkson,+NY+12446/@41.8887052,-74.313213,17z/data=!3m1!4b1!4m5!3m4!1s0x89dce387ed71485b:0xcacbdba473583f26!8m2!3d41.8887052!4d-74.3110243" target="_blank" title="Map">101 Ridgewood Rd, Kerhonkson, NY 12446</a>.</strong></p><p><br>Why not take a scenic journey to see the snow-capped mountaintops alongside the Hudson Valley? It's also a perfect weekend to visit a few locally owned shops and markets! </p><p>A few of our favorites: <br><strong><a data-cke-saved-href="http://www.hamiltonandadams.com" href="http://www.hamiltonandadams.com" target="_blank">Hamilton & Adams</a> </strong>- Kingston<br><strong><a data-cke-saved-href="https://loopymango.com/" href="https://loopymango.com/" target="_blank">Loopy Mango</a> </strong>- Beacon<br><strong><a data-cke-saved-href="https://www.facebook.com/fieldandbarn/" href="https://www.facebook.com/fieldandbarn/" target="_blank">Field & Barn</a> </strong>- High Falls<br><strong><a data-cke-saved-href="https://www.fruitionchocolateworks.com/" href="https://www.fruitionchocolateworks.com/" target="_blank">Fruition Chocolate</a> </strong>- Shokan<br><strong><a data-cke-saved-href="http://www.brandenburgbakery.com/" href="http://www.brandenburgbakery.com/" target="_blank">Brandenburg Bakery</a> </strong>- Livingston Manor</p><p><br>
</p><h2>Winter has Arrived in the Hudson Valley!</h2><p><img src="https://hudsonwoods.com/assets/img/journal/resized/new_Skiing_Hunter_MG_3966-20190123171507.jpg"><br><br>
</p><p>Winter has officially arrived to the Hudson Valley, and for winter sport enthusiasts this season is looking to be one of the best ever. I SKI NY, <a href="http://www.iskiny.com/">www.iskiny.com</a> announced back in November, that over $70 million in investments and enhancements for the season have been made. More then 25 resorts and mountains had committed to the venture, with enhancements in snowmaking, chair lift operations, lodging and guest services, plus more. The invested capital is far more than any other Northeastern state, and places New York as the largest investor for the season.<br><br>
</p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/new_Skiing_Plattekill_skiingfamily.jpg">
</p><p>“New York ski areas have dug deep into their own pockets to make these improvements, which will allow us to expand our Learn to Ski programs – this is incredibly exciting,” stated Scott Brandi, President of Ski Areas of New York, Inc. “Coupled investments to increase efficiency in snow grooming, lodge hospitality and lift upgrades, we hope to create life-long ski enthusiasts and welcome future generations of winter sport advocates.”
</p><p>The state wide focus on infrastructure upgrades in parallel with the efforts to optimize ski and stay offerings by expanding activities and developing new lodging packages is already paying off for both experienced and novice skiers.
</p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/new_belleayre_P1000063.jpg">
</p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/new_Verdigris_Chocolate_29-3ab64b3a-bigger.jpg">
</p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/Snow_Tubing_Hudson_Valley_Resort-20190123171755.jpg">
</p>