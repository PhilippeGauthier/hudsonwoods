---
title: The New York Times Features Hudson Woods
author: HudsonWoods
categories:
  - press
  - sustainability
  - hudson valley
featuredImage: /assets/img/journal/Black-TM.jpg
contentSummary: '<p>We are delighted to share that Hudson Woods was prominently featured in a New York Times real estate story.<br></p>'
buttons: ""
---
<p><img src="/assets/img/journal/resized/Black-TM-20200812172624.jpg"></p><p>We are delighted to share that Hudson Woods was prominently featured in a New York Times real estate story about high-style rural living that celebrates a new design aesthetic and environmental consciousness.</p><p>In the piece, reporter Jane Margolies thoughtfully weaves together how Hudson Woods has influenced—directly and indirectly–a new wave of development plans in the upstate region that have been turbocharged by the recent pandemic.</p><p><a href="https://www.nytimes.com/2020/08/11/realestate/sustainable-design-hudson-valley-connecticut.html" target="_blank">GET THE FULL STORY</a></p>