---
title: the-best-catskills-adventures-for-you-and-your-friends
author: HudsonWoods
featuredImage: ""
contentSummary: '<p><a href="https://www.thrillist.com/travel/new-york/head-for-the-catskills-with-your-friends">https://www.thrillist.com/travel/new-york/head-for...</a></p>'
buttons: ""
---
<p><a href="https://www.thrillist.com/travel/new-york/head-for-the-catskills-with-your-friends">https://www.thrillist.com/travel/new-york/head-for...</a></p>