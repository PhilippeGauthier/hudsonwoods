---
title: 14 Things to do in the Catksills This Summer
author: HudsonWoods
featuredImage: ""
contentSummary: '<p><a href="https://www.thrillist.com/travel/new-york/the-coolest-things-to-do-in-the-catskills" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://www.thrillist.com/travel/new-york/the-coolest-things-to-do-in-the-catskills&source=gmail&ust=1528379456374000&usg=AFQjCNFt1oIVEc8XP4PhyIo8BAcpZCc9Sw">https://www.thrillist.<wbr>com/travel/new-york/the-cooles<wbr>t-things-to-do-in-the-catskill<wbr>s</a></p>'
buttons: ""
---
<p><a href="https://www.thrillist.com/travel/new-york/the-coolest-things-to-do-in-the-catskills" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://www.thrillist.com/travel/new-york/the-coolest-things-to-do-in-the-catskills&source=gmail&ust=1528379456374000&usg=AFQjCNFt1oIVEc8XP4PhyIo8BAcpZCc9Sw">https://www.thrillist.<wbr>com/travel/new-york/the-cooles<wbr>t-things-to-do-in-the-catskill<wbr>s</a></p>