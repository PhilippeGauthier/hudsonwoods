---
title: The 48Hr Catskill Getaway for Couples
author: HudsonWoods
featuredImage: ""
contentSummary: '<p><a href="https://www.thrillist.com/travel/new-york/the-best-forty-eight-hour-catskills-getaways-for-couples" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://www.thrillist.com/travel/new-york/the-best-forty-eight-hour-catskills-getaways-for-couples&source=gmail&ust=1528379456374000&usg=AFQjCNGZPnCWBCrV9slPLc0Umy5J6QahKA">https://www.thrillist<wbr>.com/travel/new-york/the-best-<wbr>forty-eight-hour-catskills-<wbr>getaways-for-couples</a></p>'
buttons: ""
---
<p><a href="https://www.thrillist.com/travel/new-york/the-best-forty-eight-hour-catskills-getaways-for-couples" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://www.thrillist.com/travel/new-york/the-best-forty-eight-hour-catskills-getaways-for-couples&source=gmail&ust=1528379456374000&usg=AFQjCNGZPnCWBCrV9slPLc0Umy5J6QahKA">https://www.thrillist<wbr>.com/travel/new-york/the-best-<wbr>forty-eight-hour-catskills-<wbr>getaways-for-couples</a></p>