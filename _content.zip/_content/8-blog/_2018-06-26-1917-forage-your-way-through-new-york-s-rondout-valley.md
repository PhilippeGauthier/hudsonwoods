---
title: "​Forage Your Way Through New York's Rondout Valley"
author: HudsonWoods
featuredImage: ""
contentSummary: |
  <p><strong>Forage Your Way Through New York's Rondout Valley</strong></p><p>FOOD & WINE</p><p>This stunning little region north of Manhattan—and mere miles from two other regions you'll definitely have heard of—is an agricultural wonderland, and you can do it all in a day. <a href="https://apple.news/AYtXUAY8aSHaclCBrRmc8yA" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&q=https://apple.news/AYtXUAY8aSHaclCBrRmc8yA&source=gmail&ust=1530141093563000&usg=AFQjCNE_cS8owS8fvMWGAyBkL2pFlfDf8w">Read the full story</a></p>
buttons: ""
---
