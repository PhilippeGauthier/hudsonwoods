---
title: Journal
_template: journal
_fieldset: journal
_default_folder_template: journal_entry
---
