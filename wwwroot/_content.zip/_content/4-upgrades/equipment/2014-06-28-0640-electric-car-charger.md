---
previewImage: /assets/img/upgrades/electric-car-thumbnail.jpg
title: Electric Car Charger
specs:
  - 
    text: Blink HQ electric vehicle charger
  - 
    text: 220V charger provides fast charging of all electric vehicle models
  - 
    text: Delay timer feature to easily take advantage of off-peak utility rate
imageGallery:
  - 
    image: /assets/img/homes/electric-car-thumbnail.jpg
categories:
  - equipment
cost: $3,500
specDownload: /assets/img/upgrades/Utilities-20150707164918.pdf
imageSingle: ""
---
