---
previewImage: /assets/img/upgrades/in-floor-thumbnails.jpg
title: In-Floor Radiant Heating
specs:
  - 
    text: Provides comfortable even heat with a gently warmed floor surface
imageGallery:
  - 
    image: /assets/img/homes/in-floor-thumbnails.jpg
categories:
  - equipment
cost: 'Lower Level Only $7,000 / Full House - $16,500'
specDownload: /assets/img/upgrades/Utilities-20150707164934.pdf
imageSingle: ""
---
