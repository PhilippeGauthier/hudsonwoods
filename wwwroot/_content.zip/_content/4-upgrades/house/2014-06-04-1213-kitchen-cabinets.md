---
title: Kitchen Cabinets
categories:
  - house
specs:
  - 
    text: White oak upper cabinets
  - 
    text: Provides additional concealed storage in kitchen
previewImage: '{{ _site_root }}assets/img/upgrades/cabinets.jpg'
cost: $5,500
specDownload: '{{ _site_root }}assets/img/upgrades/Cabintes + Powder Room.pdf'
imageSingle: '{{ _site_root }}assets/img/homes/cabinets-20140727014028.jpg'
---
<p>$3,500</p>