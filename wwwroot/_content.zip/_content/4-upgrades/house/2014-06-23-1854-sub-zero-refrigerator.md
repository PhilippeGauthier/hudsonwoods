---
imageSingle: '{{ _site_root }}assets/img/homes/Fridge2.jpg'
title: Sub-Zero Refrigerator
categories:
  - house
specs:
  - 
    text: 15 Cubic feet of additional capacity
  - 
    text: 2 Freezer drawers with ice maker
cost: $9,000
previewImage: '{{ _site_root }}assets/img/upgrades/Fridge3.jpg'
---
