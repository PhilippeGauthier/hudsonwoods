---
previewImage: /assets/img/upgrades/veg-garden-thumbnail.jpg
title: Vegetable Garden
specs:
  - 
    text: '20’ X 30’ perimeter - 360 square feet of planting area'
  - 
    text: 6 interior beds of varying sizes
  - 
    text: Single cedar gate with posts 10’ above ground, with a space for vines to grow above head level
  - 
    text: '6’ high - 2” X 4” wire mesh fencing - for deer prevention'
  - 
    text: Rodent fencing 2’ below and 2’ above the ground
  - 
    text: Included in your garden package are 28 cubic yards of local topsoil
  - 
    text: Approximately 15 different types of vegetables, planted at the appropriate times.
  - 
    text: Seed and plant starts selection – depending on plants and their needs
  - 
    text: 3 months initial maintenance (2 times per week)
  - 
    text: 'Please note: harvesting not included.'
categories:
  - land
cost: $15,500
specDownload: /assets/img/upgrades/Land Upgrades-20150622102734.pdf
imageSingle: /assets/img/homes/Vegetable-Details-image.jpg
imageGallery: ""
---
<p>$14,000</p>