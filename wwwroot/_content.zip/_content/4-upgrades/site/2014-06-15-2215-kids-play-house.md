---
previewImage: /assets/img/upgrades/kids-play-house-thumbnail.jpg
title: Kids Play House
specs:
  - 
    text: 'Three level kid’s playhouse	'
  - 
    text: 'Locally-sourced black locust wood cladding	'
  - 
    text: Barn door entry, climbing rope and operable shutters
imageGallery:
  - 
    image: /assets/img/homes/3-20140727174437.jpg
  - 
    image: /assets/img/homes/4-20140727174437.jpg
  - 
    image: /assets/img/homes/5-20140727174437.jpg
categories:
  - site
cost: $30,000
specDownload: /assets/img/upgrades/Play House-20151123173903.pdf
imageSingle: ""
---
