---
title: Mountain Brauhaus
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Brahaus.jpg'
---
<p>The German kitsch decore and the menu may not had changed much since the Ruoff family opened the Mountain Brauhaus&nbsp;in 1955, but that's a good thing. Classic German cuisine and beers plus&nbsp;really good cocktails draw a&nbsp;bustling crowd,&nbsp;among them many&nbsp;weary rock climbers. Where else&nbsp;will your&nbsp;waitress be&nbsp;wearing a&nbsp;dirndl?</p><p><a href="http://www.mountainbrauhaus.com" target="_blank">mountainbrauhaus.com</a></p>