---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_A-tavola.jpg'
title: A Tavola Trattoria
activity: eat
---
<p>A Tavola Trattoria is the effort of two chefs from two of the best&nbsp;Italian restaurants in the city – Sfoglia and Al Di La. They&nbsp;combine classic Italian with local farm ingredients. We think it's the best restaurant in New Paltz.</p><p><a href="http://www.atavolany.com" target="_blank">atavolany.com</a></p>