---
title: Cucina, Woodstock
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Cucina.jpg'
---
<p>The setting alone makes this excellent, contemporary Italian restaurant worth the visit. A rambling&nbsp;rustic farmhouse and companion barn (now a gorgeous catering space) are where chef&nbsp;Giovanni Scappin&nbsp;serves&nbsp;"straight forward" but consistently delicious pastas, and a "sensational" flatbread pizza.&nbsp;</p><p><a href="http://www.cucinawoodstock.com/" target="_blank">cucinawoodstock.com</a></p>