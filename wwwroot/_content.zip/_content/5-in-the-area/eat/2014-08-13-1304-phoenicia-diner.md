---
title: Phoenicia Diner
activity: eat
---
<p>Classic diner favorites updated with a modern&nbsp;twist and ingredients&nbsp;sourced from local farms and artisans. This well maintained and well attended 50 year old&nbsp;diner is popular with the locals and hipsters alike, noted for it's well thought out menu and super friendly servers.</p><p>http://www.phoeniciadiner.com</p>