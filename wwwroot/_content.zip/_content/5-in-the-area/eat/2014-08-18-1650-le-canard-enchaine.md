---
title: Le Canard Enchainé
activity: eat
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_EAT_Canard-20140820164813.jpg'
---
<p>Classic, French cuisine that's "so behind the curve, it's probably ahead of it" says the Wall Street Journal. Come early for the almost ridiculously reasonable prix-fixe menu, or settle in later for a lavish meal, but always with&nbsp;proper French service.</p><p>http://le-canardenchaine.com</p>