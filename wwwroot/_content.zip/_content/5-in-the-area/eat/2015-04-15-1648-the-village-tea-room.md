---
title: The Village Tea Room
activity: eat
---
<p>Housed in a 200 year old building that was the village tailor shop, the Tea Room is a seasonal farm to table restaurant and bakery that reflects the wandering imagination of a former&nbsp;Union Square Café chef. The three cozy&nbsp;dining rooms are named after historical local families, and the step back in time is counteracted by the freshness of the local farm sourced ingredients and the adventurous baked goods. Open breakfast, lunch and dinner:&nbsp;http://www.thevillagetearoom.com</p>