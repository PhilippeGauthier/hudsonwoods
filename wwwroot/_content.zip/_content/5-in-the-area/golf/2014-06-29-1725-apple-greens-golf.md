---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_Apple.jpg'
title: 'Apple Greens Golf '
activity: Swing
---
<p>Just west of New Paltz, this working apple orchard shares space with 27 holes of challenging but entertaining golf&nbsp;terrain. It's a beautiful course worthy of its own&nbsp;day trip from the city. Wonderful in all seasons, but particularly late summer and early fall when you can sample the produce.&nbsp;</p><p><a href="http://www.applegreens.com" target="_blank">applegreens.com</a></p>