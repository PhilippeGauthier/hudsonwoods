---
title: 'Lazy Swan Golf & Country Club'
activity: swing
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_LazySwan-20140820165148.jpg'
---
<p>Certainly one of the best courses in Ulster County, the Lazy Swan&nbsp;is "championship caliber,"&nbsp;designed by&nbsp;Barry Jordan, and is anchored by&nbsp;a fairly swanky golf club, a&nbsp;bistro/martini lounge,&nbsp;and set of golf&nbsp;bungalows. It's fairly new (2005) and it's mountain style holes are&nbsp;in near perfect shape.<span></span></p><p>http://www.thelazyswan.com</p>