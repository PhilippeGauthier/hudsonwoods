---
title: Grossinger Country Club
activity: swing
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWING_Grossinger-20140820165133.jpg'
---
<p>Part of The Concord complex, this&nbsp;Joe Finger designed course is well noted for how it takes advantage of pre-existing terrain. Each nine at starts atop a hill and&nbsp;works down into a valley and then back to the top of the hill. Many bending holes and high reward 5's make it a fun course where you can up your game.</p><p><a href="http://www.grossingergolf.net/">www.grossingergolf.net</a></p>