---
title: ' Omega Institute '
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_Omega.jpg'
---
<p>The Omega Institute&nbsp;is a mind and spirit retreat. The Institute hums with seminars by&nbsp;hundreds of noted&nbsp;thinkers, artists and healers and draws&nbsp;over 23,000 attendees to its programs yearly.The recently constructed building to house&nbsp;the Center for Sustainable Living&nbsp;is&nbsp;worth a visit in and of itself.&nbsp;</p><p><a href="http://www.eomega.org/" target="_blank">eomega.org</a></p>