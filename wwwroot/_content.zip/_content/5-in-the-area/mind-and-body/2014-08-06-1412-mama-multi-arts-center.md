---
title: Mama Multi Arts Center
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_Mama.jpg'
---
<p>This very busy community center hosts&nbsp;Yoga classes daily, but also Tai Chi, Chi Hung, Zumba and even Chinese Straight Sword sessions.&nbsp;</p><p><a href="http://www.cometomama.org/" target="_blank">cometomama.org</a></p>