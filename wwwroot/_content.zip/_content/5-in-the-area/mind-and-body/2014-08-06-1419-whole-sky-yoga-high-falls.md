---
title: Whole Sky Yoga
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_sky.jpg'
---
<p>Located&nbsp;in a lean, bright&nbsp;lofty space with hardwood floors in the brand new High Falls Emporium.&nbsp;Whole Sky offers classes of vinyasa and also custom yoga sessions for those who to go to the next level.&nbsp;</p><p><a href="http://www.wholeskyyoga.com/" target="_blank">wholeskyyoga.com</a></p>