---
title: Simhara Center
activity: Mind And Body
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_M&B_Simhara.jpg'
---
<p>It's unusual enough to find a full service spa in a colonial&nbsp;stone home, but Simhara aspires&nbsp;to help you&nbsp;"reach ever higher levels of holistic and restorative beauty, health, relaxation and happiness" with a&nbsp;host of services,&nbsp;treatments and yoga.&nbsp;</p><p><a href="http://www.simhara.com/" target="_blank">simhara.com</a></p>