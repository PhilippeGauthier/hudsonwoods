---
title: Westwind Orchard
activity: 'Pick & Grow'
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_P&G_Westwind-20140820165043.jpg'
---
<p>Fashion photographer Fabio Chizzola and fashion stylist Laura Ferrar are creating&nbsp;a "Holistic Community Orchard"&nbsp;on their 31 acre property in Accord.&nbsp;Already certified organic they are introducing materials like Neem oil, Effective Microbes, seaweed, Kelp and compost teas to help grow healthier soil, trees, fruits and vegetables.</p><p><a href="http://westwindorchard.com/" target="_blank">westwindorchard.com</a></p>