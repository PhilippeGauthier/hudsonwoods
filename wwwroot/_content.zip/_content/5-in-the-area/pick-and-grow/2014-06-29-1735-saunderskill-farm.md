---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_pickandgrow_sauderskill.jpg'
title: Saunderskill Farm
activity: 'Pick & Grow'
---
<p>After&nbsp;12 generations in the same family, Saunderskill Farm&nbsp;isn’t just an historical curiosity, but a thriving, growing business with almost 500 acres in production, a sprawling nursery served by 15 <a href="http://www.saunderskill.com/greenhouse.shtml">greenhouses</a>, a newly expanded 3100 square foot <a href="http://www.saunderskill.com/farm_market.shtml">market</a> selling their produce and scores of other locally sourced goods.</p><p><a href="http://www.saunderskill.com" target="_blank">saunderskill.com</a></p>