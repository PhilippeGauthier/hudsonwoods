---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SIP_Hillrock.jpg'
title: 'Hillrock Estate           '
activity: Sip
---
<p>The Hillrock Distillery is a&nbsp;“field-to-glass” craft distilling operation, i.e. farm-to-table for booze. Hillrock’s custom-made copper distillation equipment gives them extraordinary control over the quality of each batch. They produce&nbsp;aged Bourbon, and will release a single malt whiskey and a rye in the coming months.&nbsp;</p><p><a href="http://hillrockdistillery.com/" target="_blank" style="background-color: initial;">hillrockdistillery.com</a></p>