---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SIP_Robibero-20140808160709.jpg'
title: Robibero Family Vineyards
activity: Sip
---
<p>A fairly new vineyard on the New York scene, Robibero is also one of the most scenic, located on&nbsp;42 acres in and around the Shawangunk Ridge. It's a family operation who's mission is less corporate and more about passion. Wines are crafted in small lots, in&nbsp;very limited production and sold mostly on site.&nbsp;<br><a href="http://www.rnewyorkwine.com" target="_blank">rnewyorkwine.com</a><br><a href="http://www.rnewyorkwine.com"></a></p>