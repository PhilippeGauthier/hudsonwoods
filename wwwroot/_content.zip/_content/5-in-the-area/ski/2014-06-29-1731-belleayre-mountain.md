---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SKI_Bellayre.jpg'
title: Belleayre Mountain
activity: Ski
---
<p><span>Belleayre Ski Center is located in the unblemished Catskill Forest Preserve on "forever wild" land. Visitors can Ski and snowboard the trails that descend through silent, pristine woodlands of the Forest.</span></p><p><span><a href="http://www.belleayre.com/" target="_blank">belleayre.com</a><br></span></p>