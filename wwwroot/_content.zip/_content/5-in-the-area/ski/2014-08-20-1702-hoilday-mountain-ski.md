---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SKI_Holiday.jpg'
title: 'Holiday Mountain Ski & Fun Park'
activity: ski
---
<p>4 lifts service&nbsp;7 slopes and trails of varying skill levels but&nbsp;mostly for kids and beginners. Other fun stuff includes a tubing hill and&nbsp;night skiing on all trails. Come Summer, the area turns into a kid-cetric resort with bumper boats, go-karts, mini-golf, batting cages,&nbsp;bungee trampolines, and on and on&hellip;</p><p>http://www.holidaymtn.com</p>