---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SLEEP_Dylan.jpg'
title: The Hotel Dylan
activity: Sleep
---
<p>The Hotel Dylan bills itself as&nbsp;a gateway to the&nbsp;music and the arts of&nbsp;the Hudson Valley.&nbsp;Reflecting the bohemian spirit of Woodstock&nbsp;it's more&nbsp;Scandinavian chic than hippy and tie-die. The rooms look out over a central&nbsp;lawn where&nbsp;you can engage in "spontaneous leisure" activities like&nbsp;ping-pong, badminton,&nbsp;bocce ball, or just lazing in the hammock.&nbsp;<a href="http://thehoteldylan.com/">thehoteldylan.com</a></p>