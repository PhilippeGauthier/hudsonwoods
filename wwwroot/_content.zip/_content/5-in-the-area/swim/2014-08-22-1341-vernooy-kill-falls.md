---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWIM_Vernooy.jpg'
title: Vernooy Kill Falls
activity: Swim
---
<p>Gently sloping cascades, a gentle waterfall&nbsp;and a kid friendly 4 mile round trip hike. Enter at 576 Upper Cherrytown Road.&nbsp;</p><p><a href="http://www.trails.com/tcatalog_trail.aspx?trailid=HGN065-021">http://www.trails.com/tcatalog_trail.aspx?trailid=HGN065-021</a></p>