---
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_SWIM_Peekamoose.jpg'
title: Peekamoose Blue Hole
activity: Swim
---
<p>A deep (and sort of blue) &nbsp;swimming hole on the Rondout Creek fed by water rushing through a gap in a rock. When you do your cannonball off the rocks on shore, you'll notice the water is rather cold.</p><p>http://swimming-holes.info/item/peekamoose-blue-hole/</p>