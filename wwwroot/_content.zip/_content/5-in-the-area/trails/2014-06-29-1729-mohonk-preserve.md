---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_trails_mohonk.jpg'
title: 'Mohonk Preserve	'
activity: Trails
---
<p>Most famous for it's highly technical rock climbing routes on the ridges known as "The 'Gunks", the 8000 acre Mohonk Preserve is also accessible to the non-hard-hatted with 30 miles of gentle carriageways. It contains sections of the Appalachian Trail.</p><p><a href="http://www.mohonkpreserve.org/" target="_blank">mohonkpreserve.org/</a></p>