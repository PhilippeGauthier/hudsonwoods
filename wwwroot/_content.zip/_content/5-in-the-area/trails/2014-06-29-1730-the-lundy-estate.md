---
image: '{{ _site_root }}assets/img/in-the-area/inthearea_trails_lundy.jpg'
title: 'The Lundy Estate	'
activity: Trails
---
<p>Formerly the private estate of famed restaurateur owner of Lundy's in Brooklyn, the 5400 acre preserve is a playground for mountain bikers and hikers.</p><p><a href="http://www.fatsinthecats.com/trail.php?id=42" target="_blank">fatsinthecats.com/trail.php?id=42</a></p><p><a href="http://www.fatsinthecats.com/trail.php?id=42"></a></p>