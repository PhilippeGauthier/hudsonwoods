---
title: Ashokan Reservoir
activity: Trails
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_TRAILS_Ashokan-20140820165254.jpg'
---
<p>Bike, walk or&nbsp;run around New York City's most attractive&nbsp;drinking water. The historic and beautiful Ashokan Reservoir was completed in 1915 and still supplies 40% of NYC's daily usage. The views across the basin to the Catskills is awesome,&nbsp;and the bridges and old&nbsp;stonework&nbsp;have the effect of bringing you back in time.&nbsp;Very easy wide,&nbsp;paved trails are great for any&nbsp;athletic level.</p><p>http://www.nyc.gov/html/dep/html/watershed_protection/ashokan.shtml</p>