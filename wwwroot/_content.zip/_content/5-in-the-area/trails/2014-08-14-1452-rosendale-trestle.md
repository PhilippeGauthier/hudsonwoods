---
title: Rosendale Trestle
activity: Trails
image: '{{ _site_root }}assets/img/in-the-area/InTheArea_TRAILS_Trestle.jpg'
---
<p>The most impressive stage along&nbsp;the 24 mile long Walkill Valley Rail Trail, this refurbished train&nbsp;truss bridge that&nbsp;crosses over the Rondout Creek&nbsp;dates back to 1872. Peer over Rosendale, and while you're there, marvel that rail trail now extends continuously from Gardiner to Kingston thanks in large part&nbsp;to the efforts of the Open Space Institute.</p><p>http://www.wvrta.org</p>