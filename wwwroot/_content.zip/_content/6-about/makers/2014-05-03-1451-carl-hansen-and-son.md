---
image: '{{ _site_root }}assets/img/makers/Carl-Henson.png'
title: 'Carl Hansen & Søn'
makerTitle: 'Carl Hansen & Søn'
makerTagline: Danish design rooted in centuries of craftsmanship tradition
link: http://www.carlhansen.com/
logo: '{{ _site_root }}assets/img/makers/Carlhansen-Logo.jpg'
---
