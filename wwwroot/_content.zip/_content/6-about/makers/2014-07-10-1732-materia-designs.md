---
image: '{{ _site_root }}assets/img/makers/Materia-Designs.jpg'
title: Materia Designs
makerTitle: Materia Designs
makerTagline: 'A custom furniture studio also making lighting & accessories located in Kerhonkson, NY'
link: http://materiadesigns.com/
logo: '{{ _site_root }}assets/img/makers/Materia-Logo.jpg'
---
alksjdf;aklsdfja