---
title: 'Poritz & Studio'
image: /assets/img/makers/KaplanDesk-1-20151016184640.jpg
logo: '/assets/img/makers/Poritz-&-Studio-Logo-20151016184628.jpg'
makerTitle: 'Poritz & Studio'
makerTagline: A furniture and ceramics studio based out of Brooklyn, New York
link: http://www.poritzandstudio.com/
---
