---
image: '{{ _site_root }}assets/img/makers/SunValley.png'
title: Sun Valley Bronze
makerTitle: Sun Valley Bronze
makerTagline: Hardware crafted using the highest quality art-grade bronze
link: http://www.sunvalleybronze.com/home
logo: '{{ _site_root }}assets/img/makers/SVB-Logo-20140728140409.jpg'
---
