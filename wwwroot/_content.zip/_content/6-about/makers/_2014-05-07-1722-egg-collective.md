---
image: /assets/img/makers/Egg-Collective.jpg
title: Egg Collective
makerTitle: Egg Collective
makerTagline: New York design company committed to building American-made furniture
link: http://www.eggcollective.com/
logo: /assets/img/makers/Egg-Logo.jpg
---
