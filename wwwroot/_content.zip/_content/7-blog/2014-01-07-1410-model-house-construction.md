---
featuredImage: '{{ _site_root }}assets/img/journal/Blog_Image_Feature.jpg'
title: Model House Construction
categories:
  - architecture
contentSummary: '<p>Construction of the first house at Hudson Woods is underway. When completed in April, prospective buyers will be invited to view the model home.</p>'
videoEmbed: '<iframe src="//player.vimeo.com/video/83601942" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>'
author: HudsonWoods
---
<p>Construction of the first house at Hudson Woods is underway. When completed in April, prospective buyers will be invited to view the model home.</p><p>As the house is constructed, progress is being recorded by a DSLR camera on site shooting time lapse photography every 30 minutes. To date, approximately 500 photos have been taken, which comprise the video seen here.</p>