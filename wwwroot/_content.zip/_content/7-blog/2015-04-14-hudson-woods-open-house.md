---
title: Hudson Woods Open House
author: HudsonWoods
featuredImage: /assets/img/journal/Open-House-Lede.jpg
categories:
  - hudson woods
  - open house
  - hudson valley
contentSummary: '<p>We would like to announce that Hudson Woods is resuming open house hours starting this Sunday April 19th from 11:00 AM - 1:00 PM and continuing every Sunday for the duration of Spring, Summer and Fall.</p>'
---
<p>We would like to announce that Hudson Woods is resuming open house hours starting this Sunday April 19th from 11:00 AM - 1:00 PM and continuing every Sunday for the duration of Spring, Summer and Fall. Take a tour of the model home, explore the surrounding area and meet with the Architect, Drew Lang who hosts the open house. We hope to see you there!<br></p><p><img src="/assets/img/journal/resized/1-20150414114013.jpg"></p><p><img src="/assets/img/journal/resized/2-20150414114022.jpg"><br></p><p><img src="/assets/img/journal/resized/3-20150414114036.jpg"></p><p><img src="/assets/img/journal/resized/4-20150414114111.jpg"></p><p><img src="/assets/img/journal/resized/5-20150414114118.jpg"></p><p><img src="/assets/img/journal/resized/6-20150414114127.jpg"><br></p><p><img src="/assets/img/journal/resized/7-20150414114134.jpg"><br></p><p><img src="/assets/img/journal/resized/8-20150414114141.jpg"></p><p><br></p>