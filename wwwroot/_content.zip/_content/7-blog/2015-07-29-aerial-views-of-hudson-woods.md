---
title: Aerial Views of Hudson Woods
author: HudsonWoods
featuredImage: /assets/img/journal/Drone-Still.png
categories:
  - hudson valley
  - mountains
  - catksills
contentSummary: '<p>See what lies just beyond the tree line of Hudson Woods in this aerial video. Dense woods, short and long range mountain views abound with new angles from which to view the model house and construction progress. The video provides context for our location amidst the Catskill Mountains in the heart of the Hudson Valley.<br></p>'
videoEmbed: '<iframe src="https://player.vimeo.com/video/134954473" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/134954473">Hudson Woods Aerial Views</a> from <a href="https://vimeo.com/hudsonwoods">Hudson Woods</a> on <a href="https://vimeo.com">Vimeo</a>.</p> <p>See what lies just beyond the tree line of Hudson Woods in this aerial video. Dense woods, short and long range mountain views abound with new angles from which to view the model house and construction progress. The video provides context for our location amidst the Catskill Mountains in the heart of the Hudson Valley.​</p>'
---
<p><br></p>