---
title: Winter Open House with Drew Lang
author: HudsonWoods
categories:
  - community
  - event
  - local
featuredImage: /assets/img/journal/IMG_1031-20160113190944.jpg
contentSummary: '<p>Join us on Sunday, January 31st for a winter open house at Hudson Woods, hosted by Architect, Drew Lang. Get to know the area and chat with Drew about all things Hudson Woods. Explore the model house, warm up and hang out by our wood burning stove with a hot chocolate in hand. We will also roast marshmallows so bring the whole family and pets are always welcome! We look forward to having a good, cozy time. We hope to see you there.</p>'
---
<p><img src="/assets/img/journal/resized/IMG_1031_1.jpg"></p><p><strong><br>Winter Open House: Sunday, January 31st 12:00 PM - 4:00 PM</strong><br></p><p>Join us on Sunday, January 31st for a winter open house at Hudson Woods, hosted by Architect, Drew Lang. Get to know the area and chat with Drew about all things Hudson Woods. Explore the model house, warm up and hang out by our wood burning stove with a hot chocolate in hand. We will also roast marshmallows so bring the whole family and pets are always welcome! We look forward to having a good, cozy time. We hope to see you there.<br><br></p><p><img src="/assets/img/journal/resized/a65e8f7b-9551-4680-ad0b-93f8bd922435.png"></p><p><img src="/assets/img/journal/resized/8A2A0536-20160113193104.jpg"><br></p><p><img src="/assets/img/journal/resized/151023_HudsonWoods-0931_1.jpg"><br><br></p>