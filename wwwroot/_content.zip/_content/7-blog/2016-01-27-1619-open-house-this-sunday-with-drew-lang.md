---
title: Open House This Sunday With Drew Lang
author: HudsonWoods
featuredImage: /assets/img/journal/Open-House-20160127184135.png
categories:
  - open house
  - hudson woods
  - events
  - community
contentSummary: '<p>A friendly reminder that we are holding an open house this Sunday hosted by Architect, Drew Lang. Small batch local hot chocolate will be served by our friends from <a href="http://hudsonwoods.com/blog/from-the-source-fruition-chocolate" target="_blank">Fruition Chocolate</a> along with homemade marshmallows. We will also have <a href="http://hettaglogg.com/history/" target="_blank">Glogg</a>, a spiced red wine of Nordic Origin and wine from our friends at <a href="http://hudsonwoods.com/blog/from-the-source-kingston-wine-co" target="_blank">Kingston Wine Co.</a> </p>'
---
<p><img src="/assets/img/journal/resized/Open-House.png"></p><p><br><strong>Winter Open House: Sunday, January 31st 12:00 PM - 4:00 PM</strong></p><p>A friendly reminder that we are holding an open house this Sunday hosted by Architect, Drew Lang. Small batch local hot chocolate will be served by our friends from <a href="http://hudsonwoods.com/blog/from-the-source-fruition-chocolate" target="_blank">Fruition Chocolate</a> along with homemade marshmallows. We will also have <a href="http://hettaglogg.com/history/" target="_blank">Glogg</a>, a spiced red wine of Nordic heritage and wine from our friends at <a href="http://hudsonwoods.com/blog/from-the-source-kingston-wine-co" target="_blank">Kingston Wine Co.</a> Come by to get to know the area and chat with Drew about all things Hudson Woods. Explore the model house, warm up and get cozy by our wood burning stove. Bring the whole family and pets are always welcome! We hope to see you there.<br><br></p><p><span></span></p><p><img src="/assets/img/journal/resized/1-20160127180812.jpg"></p><p><img src="/assets/img/journal/resized/4-20160127180821.jpg"></p><p><img src="/assets/img/journal/resized/3-20160127181453.jpg"></p><p><br><br></p>