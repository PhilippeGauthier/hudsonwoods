---
title: $500 Gift Certificate to Baked for Hudson Woods Buyers
author: HudsonWoods
featuredImage: /assets/img/journal/1-20160208175900.jpg
categories:
  - new york
  - food
  - community
contentSummary: '<p>BAKED and Hudson Woods have teamed up to offer a $500 gift certificate to buyers who purchase a Hudson Woods home in the winter of 2016 prior to March 31st. BAKED is a take on the “Great American Bakery” that has become a New York institution, opened by two guys pursuing a passion and a dream.</p>'
---
<p><img src="/assets/img/journal/resized/1-20160208175743.jpg"></p><p><br>BAKED and Hudson Woods have teamed up to offer a $500 gift certificate to buyers who purchase a Hudson Woods home in the winter of 2016 prior to March 31st. <a href="https://www.bakednyc.com/about/our-story/" target="_blank">BAKED</a> is a take on the “Great American Bakery” that has become a New York institution, opened by two guys pursuing a passion and a dream. First launched in the Red Hook neighborhood of Brooklyn, the bakery has expanded to a new location in TriBeCa along with a plethora of cook books, kitchen wares and products you can find on the shelves of Whole Foods and other grocery stores. <a href="http://hudsonwoods.com/contact" target="_blank">Contact us</a> for additional details. <br><br> </p><p><img src="/assets/img/journal/resized/2-20160208175800.jpg"><br></p><p><img src="/assets/img/journal/resized/3-20160208175812.jpg"></p><p><img src="/assets/img/journal/resized/Baked.jpg"></p><p><img src="/assets/img/journal/resized/5-20160208175843.jpg"></p><p><img src="/assets/img/journal/resized/Baked-1.jpg"></p><p><img src="/assets/img/journal/resized/Baked-2-20160208182055.jpg"></p>