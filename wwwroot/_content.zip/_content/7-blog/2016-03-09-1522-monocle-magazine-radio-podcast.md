---
title: Hudson Woods in Monocle Magazine Radio Podcast
author: HudsonWoods
categories:
  - news
  - press
  - architecture
featuredImage: /assets/img/journal/Monocle-Podcast-20160309154325.jpg
contentSummary: '<p>Monocle Magazine has an extensive radio platform, M24. Their programs range from politics to the arts and include “Section D” which is focused on all things design. Recently, a reporter from Section D visited Hudson Woods to speak with Drew Lang about Hudson Woods. The episode aired yesterday. </p>'
---
<p><img src="/assets/img/journal/resized/Monocle-Podcast.jpg"></p><p>Monocle Magazine has an extensive radio platform, M24. Their programs range from politics to the arts and include “Section D” which is focused on all things design. Recently, a reporter from Section D visited Hudson Woods to speak with Drew Lang about Hudson Woods. The episode aired yesterday. <br><br><a href="http://monocle.com/radio/shows/section-d/230/hudson-woods/" target="_blank"><strong>Click To Listen</strong></a><span></span></p><p><br></p>