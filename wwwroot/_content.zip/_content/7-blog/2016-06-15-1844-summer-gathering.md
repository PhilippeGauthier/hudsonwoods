---
title: Mingle With Local Makers at Hudson Woods
author: HudsonWoods
featuredImage: /assets/img/journal/Lead-20160615184639.jpg
categories:
  - event
  - summer
  - hudson valley
  - makers
contentSummary: '<p>A group of our favorite Hudson Valley furniture, lighting, and home goods makers will be joining us at the model house on the afternoon of July 23rd to mingle, enjoy local fare, & show work in an informal setting. For Hudson Woods buyers & Hudson Valley weekenders, this will be a great opportunity to meet the extraordinary talent in your neighborhood. Stop by betwee 1:00 - 5:00 PM, we hope to see you there.</p>'
---
<p><span></span>
</p><p><img src="/assets/img/journal/resized/Summer-Invite-20160615175428.jpg"><br><br>A group of our favorite Hudson Valley furniture, lighting, and home goods makers will be joining us at the model house on the afternoon of July 23rd to mingle, enjoy local fare, & show work in an informal setting. For Hudson Woods buyers & Hudson Valley weekenders, this will be a great opportunity to meet the extraordinary talent in your neighborhood. Stop by betwee 1:00 - 5:00 PM, we hope to see you there. </p><p><br>
</p><p><strong></strong></p><center><strong>Joining Us Will Be:</strong><p>Barn & Field<br>Black Creek Mercantile<br>Dzierlenga F+U<br>Materia Design<br>Michael Robbins Furniture<br>Samuel Moyer Furniture<br>Scandinavian Grace<br>Silk & Willow<br>Traditions Linens<br>Wickham Solid Wood Studio</p><p>--</p><p><strong>SATURDAY JULY 23RD 1-5 PM</strong><br>HUDSON WOODS MODEL HOUSE<br>101 RIDGEWOOD RD. KERHONKSON NY 12446</p><center><p><br>
</p></center></center>