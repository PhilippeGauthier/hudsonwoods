---
title: Open House This Sunday With Drew Lang
author: HudsonWoods
featuredImage: /assets/img/journal/1-20160707123029.jpg
categories:
  - hudson valley
  - open house
  - upstate
contentSummary: '<p>A Hudson Woods open house will be hosted this Sunday by Architect, Drew Lang. Come by to get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p>'
---
<p><img src="/assets/img/journal/resized/1-20160707122922.jpg"></p><p><strong>Open House: Sunday, July 10th 12:00 PM - 2:00 PM</strong></p><p>A Hudson Woods open house will be hosted this Sunday by Architect, Drew Lang. Come by to get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p><p><img src="/assets/img/journal/resized/2-20160707122914.jpg"></p><p><img src="/assets/img/journal/resized/3-20160707122931.jpg"></p><p><img src="/assets/img/journal/resized/4-20160707122943.jpg"></p><p><img src="/assets/img/journal/resized/5-20160707122950.jpg"></p>