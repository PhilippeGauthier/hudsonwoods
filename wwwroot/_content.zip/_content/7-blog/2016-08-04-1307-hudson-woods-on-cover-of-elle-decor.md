---
title: Hudson Woods on Cover of Elle Decor Indonesia
author: HudsonWoods
categories:
  - press
  - news
  - design
featuredImage: /assets/img/journal/COVER ELLE DECOR JUNE-JULY 2016-20160812150315.jpg
contentSummary: '<p>Hudson Woods was recently on the cover of Elle Decoration Magazine in Indonesia. Titled “Into the Woods,” the article looks at the balance between nature and architecture and the desire to escape busy city life for some peace of mind in the mountains.</p>'
---
<p>Hudson Woods was recently on the cover of Elle Decoration Magazine in Indonesia. Titled “Into the Woods,” the article looks at the balance between nature and architecture and the desire to escape busy city life for some peace of mind in the mountains. <a href="https://langarchitecture.com/news/hudson-woods-on-cover-of-elle-decor" target="_blank">Click Here</a> to download a PDF of the story.<br> </p><p><img src="/assets/img/journal/resized/COVER ELLE DECOR JUNE-JULY 2016.jpg"><br></p>