---
title: Rental Value of a Hudson Woods Home
author: HudsonWoods
featuredImage: /assets/img/journal/Lead.png
contentSummary: '<p>Many people have asked about renting a home at Hudson Woods. While at the moment there are no properties available for rent, we anticipate that in time, many Hudson Woods homes will be rented, including the model house. To test how this might work, we posted the model house on Airbnb. We quickly received a flood of booking inquiries, and compiled statistics reflecting this activity over a one week period.</p>'
categories:
  - hudson valley
  - rental
  - real estate
---
<p>Many people have asked about renting a home at Hudson Woods. While at the moment there are no properties available for rent, we anticipate that in time, many Hudson Woods homes will be rented, including the model house. To test how this might work, we posted the model house on Airbnb. We quickly received a flood of booking inquiries, and compiled statistics reflecting this activity over a one week period.<br></p><p><img src="/assets/img/journal/resized/airbnb-graphic-20160804152643.png"><br></p><p><br><br></p>