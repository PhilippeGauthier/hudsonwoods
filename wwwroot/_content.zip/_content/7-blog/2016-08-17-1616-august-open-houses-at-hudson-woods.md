---
title: 2 August Open Houses at Hudson Woods
author: HudsonWoods
categories:
  - hudson valley
  - upstate
  - new york
featuredImage: /assets/img/journal/hudsonwoods-3596-20160817175513.jpg
contentSummary: '<p>Two more open houses will be held at Hudson Woods in August. Come by to escape the summer heat in the mountains and get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.</p>'
---
<p><img src="/assets/img/journal/resized/hudsonwoods-3596.jpg"></p><p><strong>Open House Schedule: <br></strong><strong><span class="aBn"><span class="aQJ">Sunday, August 21st 12:00 PM - 2:00 PM<br></span></span></strong><strong><span class="aBn"><span class="aQJ">Sunday, August 28th 12:00 PM - 2:00 PM</span></span></strong></p><p>Two more open houses will be held at Hudson Woods in August. Come by to escape the summer heat in the mountains and get to know the area, chat with Drew about all things Hudson Woods and explore the model house. Bring the whole family and pets are always welcome! We hope to see you there.<br></p><p><img src="/assets/img/journal/resized/hudsonwoods-3722.jpg"></p><p><img src="/assets/img/journal/resized/hudsonwoods-3466.jpg"></p>