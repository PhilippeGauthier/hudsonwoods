---
title: A Beloved Hotel Re-Opens with a New Design 
author: HudsonWoods
featuredImage: /assets/img/journal/HH-20160915121838.jpg
categories:
  - hudson valley
  - community
  - design
contentSummary: '<p>One of the most historic and beloved stone mansions in nearby Stone Ridge has been given new life. The Hasbrouck House has just re-opened as a boutique hotel, restaurant and event venue under the creative direction of new owner Akiva Reich & Co.</p>'
---
<p><img src="/assets/img/journal/resized/HH.jpg"></p><p>One
 of the most historic and beloved stone mansions in nearby Stone Ridge has been given new life. The <a href="http://www.hasbrouckhouseny.com/" target="_blank">Hasbrouck House</a> has just re-opened as a boutique hotel, restaurant and event venue under the creative direction of new owner Akiva Reich & Co.</p><p>The Dutch Colonial mansion was built in 1757 and has had a most interesting and colorful past. Having originally been the seat of a branch of the famed French Huguenot Hasbroucks, it stayed in the family for over 200 years. During the later period, and until it was converted to an Inn in 1993 and proper heat was installed, the house  was used for “group housing” in the 60’s, was briefly a girls school and also a college dormitory. The latest iteration under its new ownership team promises to be a very buzzy reboot.</p><p>We
 asked what drew Akiva to purchase the Inn. “Stone Ridge has the most stone houses in the area, and this is like the cherry on the top. It was a love at first sight thing. We saw that it needed all this work but we also saw the potential.”</p><p><img src="/assets/img/journal/resized/Hasbrouck+House+Restaurant.jpg"><br>Photo by Emma Tuccilo</p><p>The
 work they have done is not inconsiderable. Working 6 and often 7 days a week over 8 months, they gut renovated the 30,000 house, added new windows and re-insulated the whole structure all while preserving original wooden details and masonry. Says Akiva, “my
 background is historic buildings, creative reuse and preservation restoration.This is completely in line with my outlook on historic buildings. I don’t knock an old building down to put a new building up, which is easier.“
</p><p>The
 Inn now has 17 guest suites, with interiors designed by his team in collaboration with local designers and makers like Materia Design, Jay teske Leather Co and Upstate Stock. Chic, but steeped in the history of the region, the look is eclectic and an homage
 to beautiful objects and classic craftsmanship.</p><p><img src="/assets/img/journal/resized/SUITE-1.jpg"><br>Photo by Emma Tuccilo<br></p><p>Just
 outside the house, Akiva’s team was equally ambitious, adding 15,000 square feet of bluestone patio space and walkways, restoring the early 1900s pool to its original state and even putting an 200 year old smokehouse back into service for Butterfield, the
 newly created farm friendly restaurant that now anchors the hotel and whose chef and menu we will detail in another post. The restaurant and bar will also be outward facing with a huge patio for eating and drinking en plein air.</p><p>They
 have expanding walking trails into the abutting Stone Ridge Orchard and will encourage guests to get outside day and night with a fleet of bikes, picnic baskets and evening bonfires by the now larger lake.
</p><p>Says
 Akiva of what draws people to this area and what will motivate people to be his guests, “I think people are coming to the realization that you need a balance, and addresses the need for a balance. Its beautiful.”</p><p><img src="/assets/img/journal/resized/Hasbrouck_House_(c)_Emma_Tuccillo_000.jpg"><br>Photo by Emma Tuccilo<br></p><p><img src="/assets/img/journal/resized/Hasbrouck_House_(c)_Emma_Tuccillo_003.jpg"><br>Photo by Emma Tuccilo<br></p><p><img src="/assets/img/journal/resized/Hasbrouck_House_(c)_Emma_Tuccillo_014.jpg"><br>Photo by Emma Tuccilo<br></p><p><img src="/assets/img/journal/resized/static1.squarespace-20160915121255.jpg"><br>Photo by Heidi's Bridge</p><p><img src="/assets/img/journal/resized/160608_Butterfields-20.png"><br>Photos by Heidi's Bridge<br><br></p><p><img src="/assets/img/journal/resized/HasbrouckHouse-28.jpg"><br></p><p><img src="/assets/img/journal/resized/HasbrouckHouse-Fall-43.jpg"></p><p><img src="/assets/img/journal/resized/HasbrouckHouse-Fall-31.jpg"></p>