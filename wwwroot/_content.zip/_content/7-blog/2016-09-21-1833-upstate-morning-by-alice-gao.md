---
title: Upstate Mornings by Alice Gao
author: HudsonWoods
categories:
  - hudson valley
  - design
  - photography
featuredImage: /assets/img/journal/Lead-20160921183621.jpg
contentSummary: "<p>A few weeks ago, our friends and well known photographer, Alice Gao, had a chance to stay at and photograph the model house. Alice was able to strike the perfect mood between of the approaching fall months at Hudson Woods, a favorite time of year in the Hudson Valley. You can see the entire blog post with additional photos on Alice's blog here. </p>"
---
<p><img src="/assets/img/journal/resized/1-20160921183734.jpg"></p><p><br></p><p>A few weeks ago, our friend and well known photographer, <a href="http://www.alicegao.com/" target="_blank">Alice Gao</a>, had a chance to stay at and photograph the model house. With an eye for fashion and a keen sense of style, Alice was able to strike the perfect mood of the approaching fall months at Hudson Woods, a favorite time of year upstate. You can see the entire blog post with additional photos on <a href="http://www.lingered-upon.com/2016/08/is-it-fall-yet.html" target="_blank">Alice's blog here</a>. </p><p><br></p><p><img src="/assets/img/journal/resized/2-20160921183806.jpg"></p><p><img src="/assets/img/journal/resized/3-20160921183816.jpg"></p><p><img src="/assets/img/journal/resized/4-20160921183823.jpg"></p>