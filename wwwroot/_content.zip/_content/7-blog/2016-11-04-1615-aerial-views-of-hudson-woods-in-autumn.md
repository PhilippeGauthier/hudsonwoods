---
title: 11 Aerial Views of Hudson Woods in Autumn
author: HudsonWoods
categories:
  - hudson valley
  - catskills
  - autumn
featuredImage: /assets/img/journal/1-20161114180900.jpg
contentSummary: '<p>Our friends at Propellerheads Aerial Photography<span class="redactor-invisible-space"> stopped by Hudson Woods last week to capture some incredible aerial photography of the site and surrounding area during the incredible fall foliage season. The photos are quite stunning and in several you can see the Catskills rising just above the tree horizon. </span></p>'
---
<p><img src="/assets/img/journal/resized/1-20161114180907.jpg"><br></p><p>Our friends at Propellerheads Aerial Photography stopped by Hudson Woods last week to capture some incredible aerial photography of the site and surrounding area during the incredible fall foliage season. The photos are quite stunning and in several you can see the Catskills rising just above the tree horizon.</p><p><img src="/assets/img/journal/resized/2-20161114181543.jpg"></p><p><img src="/assets/img/journal/resized/3-20161114181553.jpg"></p><p><img src="/assets/img/journal/resized/4-20161114181603.jpg"></p><p><img src="/assets/img/journal/resized/5-20161114181613.jpg"></p><p><img src="/assets/img/journal/resized/6-20161114181627.jpg"></p><p><img src="/assets/img/journal/resized/7-20161114181638.jpg"></p><p><img src="/assets/img/journal/resized/8-20161114181650.jpg"></p><p><img src="/assets/img/journal/resized/9-20161114181703.jpg"></p><p><img src="/assets/img/journal/resized/10-20161114181713.jpg"></p><p><img src="/assets/img/journal/resized/11-20161114181727.jpg"></p>