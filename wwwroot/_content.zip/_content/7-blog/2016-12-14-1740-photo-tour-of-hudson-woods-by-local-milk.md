---
title: Photo Tour of Hudson Woods by Beth Kirby of Local Milk
author: HudsonWoods
featuredImage: /assets/img/journal/1-20161207151707.jpg
categories:
  - photography
  - architecture
  - hudson valley
contentSummary: |
  <p>Recently our friend Beth Kirby stayed at Hudson Woods and photographed the model house. You might be familiar with her photography and blog called <a href="http://localmilkblog.com/" target="_blank">Local Milk</a>. Below we selected a few of Beth's photos for her tour of the model house.</p>
---
<p><img src="/assets/img/journal/resized/1-20161206174702.jpg"></p><p>Recently our friend Beth Kirby stayed at Hudson Woods and photographed the model house. You might be familiar with her photography and blog called <a href="http://localmilkblog.com/" target="_blank">Local Milk</a>. Below we selected a few of Beth's photos for her tour of the model house. </p><p><img src="/assets/img/journal/resized/2-20161206174208.jpg"></p><p><img src="/assets/img/journal/resized/3-20161206174216.jpg"></p><p><img src="/assets/img/journal/resized/3a-20161206174831.jpg"></p><p><img src="/assets/img/journal/resized/4-20161206174226.jpg"></p><p><img src="/assets/img/journal/resized/9-20161206174911.jpg"></p><p><img src="/assets/img/journal/resized/5-20161206174857.jpg"></p><p><img src="/assets/img/journal/resized/6-20161206174938.jpg"></p><p><img src="/assets/img/journal/resized/7-20161206174949.jpg"><br></p><p><img src="/assets/img/journal/resized/11-20161206175048.jpg"></p><p><img src="/assets/img/journal/resized/10-20161206175000.jpg"></p><p><img src="/assets/img/journal/resized/11-20161206175059.jpg"></p><p><img src="/assets/img/journal/resized/12-20161206175108.jpg"><br></p><p><img src="/assets/img/journal/resized/13-20161206175115.jpg"></p><p><img src="/assets/img/journal/resized/16-20161206175124.jpg"><br></p><p><img src="/assets/img/journal/resized/19-20161206175200.jpg"></p><p><img src="/assets/img/journal/resized/17-20161206175135.jpg"><br></p><p><img src="/assets/img/journal/resized/18-20161206175209.jpg"></p><p><br></p>