---
title: 'Photo Tour by Melissa Shelton of Carl Hansen & Søn'
author: HudsonWoods
categories:
  - photography
  - architecture
  - design
featuredImage: /assets/img/journal/1-20170104123912.jpg
contentSummary: '<p>Over the holidays, our friend Melissa Shelton of <a href="http://www.carlhansen.com/" target="_blank">Carl Hansen & Søn</a> stayed at Hudson Woods. You might recall our journal entry about <a href="https://hudsonwoods.com/blog/from-the-source-carl-hansen-and-son-1" target="_blank">Carl Hansen & Søn</a> who outfitted the model house with several furniture items. Melissa captured some beautiful moments during her stay which we want to share with you.</p>'
---
<p><img src="/assets/img/journal/resized/1-20170104123922.jpg"></p><p>Over the holidays, our friend Melissa Shelton of <a href="http://www.carlhansen.com/" target="_blank">Carl Hansen & Søn</a> stayed at Hudson Woods. You might recall our journal entry about <a href="https://hudsonwoods.com/blog/from-the-source-carl-hansen-and-son-1" target="_blank">Carl Hansen & Søn</a> who outfitted the model house with several furniture items. Melissa captured some beautiful moments during her stay which we want to share with you below: </p><p><img src="/assets/img/journal/resized/2-20170104123940.jpg"></p><p><img src="/assets/img/journal/resized/3-20170104130650.jpg"></p><p><img src="/assets/img/journal/resized/4-20170104130659.jpg"></p><p><img src="/assets/img/journal/resized/5-20170104130709.jpg"></p><p><img src="/assets/img/journal/resized/6-20170104130717.jpg"></p><p><img src="/assets/img/journal/resized/7-20170104130734.jpg"></p><p><img src="/assets/img/journal/resized/8-20170104130742.jpg"></p>