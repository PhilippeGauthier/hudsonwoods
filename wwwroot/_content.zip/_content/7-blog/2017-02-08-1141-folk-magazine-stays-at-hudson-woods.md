---
title: Photo Tour of Hudson Woods by Folk Magazine
author: HudsonWoods
categories:
  - photography
  - architecture
  - hudson valley
featuredImage: /assets/img/journal/HUDSONWOODS_009-20170206121156.jpg
contentSummary: '<p>A few weeks ago, our friends Paige Denkin and Corey Christian of <a href="https://folkmagazine.squarespace.com/blog/2017/1/30/a-stay-at-hudson-woods" target="_blank">Folk Magazine</a> stopped by Hudson Woods. They captured some beautiful moments during the stay which we want to share with you below. </p>'
---
<p><img src="/assets/img/journal/resized/HUDSONWOODS_001.jpg"></p><p>A few weeks ago, our friends Paige Denkin and Corey Christian of <a href="https://folkmagazine.squarespace.com/blog/2017/1/30/a-stay-at-hudson-woods" target="_blank">Folk Magazine</a> stopped by Hudson Woods. They captured some beautiful moments during the stay which we want to share with you below. You can find more on the Folk Magazine website here: <a href="https://hudsonwoods.com/blog/photo-tour-by-melissa-shelton">https://hudsonwoods.com/blog/photo-tour-by-melissa...</a></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_004.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_009.jpg"><br></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_012.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_026.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_033.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_044.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_045.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_052.jpg"></p><p><img src="/assets/img/journal/resized/HUDSONWOODS_054.jpg"></p><p><br></p>