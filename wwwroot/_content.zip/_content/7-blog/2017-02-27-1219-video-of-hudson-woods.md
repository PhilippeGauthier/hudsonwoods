---
title: Video Tour of Hudson Woods From Folk Magazine
author: HudsonWoods
featuredImage: /assets/img/journal/HUDSONWOODS_052-20170227113903.jpg
videoEmbed: '<iframe width="560" height="315" src="https://www.youtube.com/embed/4ExGZdSzpqk" frameborder="0" allowfullscreen></iframe>'
contentSummary: '<p>A few weeks ago we shared photos of Hudson Woods taken by our friends from Folk Magazine, Paige Denkin and Corey Christian. Recently they also released a video of their stay at Hudson Woods courtesy of their production company: <a href="http://www.goinghome.co">www.goinghome.co</a></p>'
categories:
  - architecture
  - photography
  - video
---
<p>A few weeks ago we <a href="https://hudsonwoods.com/blog/folk-magazine-stays-at-hudson-woods" target="_blank">shared photos</a> of Hudson Woods taken by our friends from <a href="https://folkmagazine.squarespace.com/blog/2017/1/30/a-stay-at-hudson-woods" target="_blank">Folk Magazine</a>, Paige Denkin and Corey Christian. Recently they also released a video of their stay at Hudson Woods courtesy of their production company: <a href="http://www.goinghome.co">www.goinghome.co</a></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.28.22 PM.png"></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.30.26 PM.png"></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.29.52 PM.png"></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.28.57 PM.png"></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.30.16 PM.png"></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-02-27 at 12.31.07 PM.png"></p><p><br></p>