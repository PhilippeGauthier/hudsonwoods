---
title: Wall Street Journal Features Hudson Woods Home Owners
author: HudsonWoods
categories:
  - press
  - architecture
  - design
featuredImage: /assets/img/journal/Lead-20170420130121.jpg
contentSummary: "<p>This week, the Wall Street Journal wrote about Paul and Sheena Murphy, who were one of the early home buyers at Hudson Woods. Sheena is an interior designer whose work we have profiled in the past and her husband, Paul is a game designer and developer. With roots in Brooklyn they decided to make a more permanent second home in the Hudson Valley. You can read the article below and learn more about Paul and Sheena's story. </p>"
---
<p><img src="/assets/img/journal/resized/IMG_5634-20170421115039.jpg"></p><p>This week, the <a href="https://www.wsj.com/articles/a-brooklyn-couples-woodsy-retreat-1492526668" target="_blank">Wall Street Journal</a> wrote about Paul and Sheena Murphy, who were one of the early home buyers at Hudson Woods. Sheena is an interior designer whose work we have <a href="https://hudsonwoods.com/blog/designer-spotlight-sheena-murphy" target="_blank">profiled</a> in the past and her husband, Paul is a game designer and developer. With roots in Brooklyn they decided to make a more permanent second home in the Hudson Valley. You can see the article below ato learn more about Paul and Sheena's story or download the article on the <a href="https://langarchitecture.com/news/wall-street-journal-murphy-house" target="_blank">Lang Architecture website</a>. </p><p><img src="https://hudsonwoods.com/assets/img/journal/resized/Screen%20Shot%202017-04-20%20at%2011.05.53%20AM-20170421115137.png"><br></p><p><img src="/assets/img/journal/resized/Screen Shot 2017-04-20 at 11.06.04 AM.png"></p><p><br></p><p><br></p><p><br></p>