---
title: Hudson Woods Video Featuring Architect, Drew Lang
author: HudsonWoods
featuredImage: /assets/img/journal/HW-Video-Still.jpg
videoEmbed: '<iframe src="https://player.vimeo.com/video/155562586" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> <p><a href="https://vimeo.com/155562586">Hudson Woods Interview With the Architect</a> from <a href="https://vimeo.com/hudsonwoods">Hudson Woods</a> on <a href="https://vimeo.com">Vimeo</a>.</p>'
categories:
  - hudson woods
  - architecture
  - video
contentSummary: '<p>Watch a video with Architect Drew Lang discussing the origin and philosophy of Hudson Woods. Drew discusses vernacular farm buildings and nature from which inspiration for the project was drawn. He also speaks about the significance of working with local craftsmen. The video captures moments and details, conveying the essence of Hudson Woods.</p>'
---
<p>Watch a video with Architect Drew Lang discussing the origin and philosophy of Hudson Woods. Drew discusses vernacular farm buildings and nature from which inspiration for the project was drawn. He also speaks about the significance of working with local craftsmen. The video captures moments and details, conveying the essence of Hudson Woods.</p>