---
title: One Lot Remains at Hudson Woods; Plus Calico Wallpaper Installation
author: HudsonWoods
featuredImage: /assets/img/journal/1-Lead-20170718173401.jpg
contentSummary: '<p>With a contract out for lot 18, we are excited to announce that lot 08/09 remains the last available lot at Hudson Woods. Only 3 years after launch, more than half of the homes are now completed with the other half in various stages of construction.</p>'
categories:
  - events
  - real estate
  - open house
---
<p><img src="/assets/img/journal/resized/1-Lead.jpg"><br><em><span style="color: rgb(89, 89, 89);"></span>Photo by Matthew Williams</em>
</p><p>With a contract out for lot 18, we are excited to announce that lot 08/09 remains the last available lot at Hudson Woods. Only 3 years after launch, more than half of the homes are now completed with the other half in various stages of construction.</p><p>We also recently partnered with our friends at <a href="http://calicowallpaper.com/" target="_blank">Calico Wallpaper</a> who well known and highly regarded in the design community for their wallpaper styles, especially in the New York area. They created an installation at the model house inspired by the wooded landscape and clear blue skies of the area. The panels they created are 100 percent linen using ombré dip-dye techniques with fiber-reactive dyes and sea salt. The process evolved out of their discovery of Hudson Woods and the development of the triptych evolved over the course of the project. <a href="http://www.architecturaldigest.com/story/calico-wallpaper-temporary-installation-catskille-hudson-woods-valley" target="_blank">Click here</a> to learn more in an article from Architectural Digest about the project. Below you can find property photos from the summer at Hudson Woods.<br><br></p><p><img src="/assets/img/journal/resized/1-20170720094541.jpg"><br><em>Photo by Robert <span class="il">Andersen</span></em></p><p><img src="/assets/img/journal/resized/6-20170718173245.jpg"><br><em>Photo by Matthew Williams</em><br></p><p><img src="/assets/img/journal/resized/7-20170718173256.jpg"><br><em>Photo by Matthew Williams</em><br></p><p><img src="/assets/img/journal/resized/8-20170718173317.jpg"><br><em>Photo by Matthew Williams</em><br></p><p><img src="/assets/img/journal/resized/a-20170720142200.PNG"><br><em>Photos by Rikki Snyder</em></p><p><img src="/assets/img/journal/resized/hudsonwoods-3722-20170720121323.jpg"><br><em>Photo by Jen Brister</em><br></p><p><img src="/assets/img/journal/resized/unnamed-4-20170720130951.jpg"><br><em>Photo by James Murray</em><br>
</p><p><img src="/assets/img/journal/resized/z.PNG"><br><em>Photos by Jen Brister</em><br>
</p><p><img src="/assets/img/journal/resized/20140719_HudsonWoods-18.jpg"><br><em>Photo by Rikki Snyder</em><br>
</p><p><br>
</p>