---
title: "CNN Article: New York's Catskills see a big vacation revival"
author: HudsonWoods
featuredImage: /assets/img/journal/Mohonk-Summer-SignatureShot-20170726182418.jpg
categories:
  - catskills
  - news
  - travel
contentSummary: '<p>This week CNN Travel covered the Catskill Mountains as an an emerging vacation destination. The article looks at why the area has become popular for travelers and transplants alike and covers where to stay, eat and explore the area, including an interview with the owner of one of our favorite brunch locations, The Phoenicia Diner. </p>'
---
<p><img src="/assets/img/journal/resized/Mohonk-Summer-SignatureShot-20170726181347.jpg"><br><br>This week CNN Travel covered the Catskill Mountains as an an emerging vacation destination. The article looks at why the area has become popular for travelers and transplants alike and covers where to stay, eat and explore the area, including an interview with the owner of one of our favorite brunch locations, The Phoenicia Diner. Read the full article <a href="http://www.cnn.com/travel/article/catskills-new-york-vacation-revival/">here</a>.</p><p><img src="/assets/img/journal/resized/170713131304-catskill-town-alexandra-marvar-super-169.jpg"></p><p><img src="/assets/img/journal/resized/170713131328-catskills-02-super-169.jpg"></p><p><img src="/assets/img/journal/resized/170713131354-catskills-03-alexandra-marvar-super-169.jpg"></p>