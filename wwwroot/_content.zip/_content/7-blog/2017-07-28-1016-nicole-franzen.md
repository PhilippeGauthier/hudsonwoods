---
title: Photo Tour by Nicole Franzen + Open House
author: HudsonWoods
featuredImage: /assets/img/journal/NF_Hudson_Woods_038-20170803130531.jpg
categories:
  - photography
  - architecture
  - design
contentSummary: '<p>Last week our friend Nicole Franzen stayed at Hudson Woods and captured some beautiful moments during her stay which we want to share with you below. Nicole travels the world photographing various locations, foods and interiors. You can catch a lot of her work here: <a href="http://www.nicolefranzen.com/">http://www.nicolefranzen.com/</a> and on Instagram. We are also holding an open house next Sunday with details below. Be sure to save the date as we only have one lot remaining for sale at Hudson Woods.</p>'
---
<p><img src="/assets/img/journal/resized/NF_Hudson_Woods_038.jpg"></p><p><br></p><p>Last week our friend Nicole Franzen stayed at Hudson Woods and captured some beautiful moments during her stay which we want to share with you below. Nicole travels the world photographing various locations, foods and interiors. You can catch a lot of her work here: <a href="http://www.nicolefranzen.com/">http://www.nicolefranzen.com/</a> and on <a href="https://www.instagram.com/nicole_franzen/" target="_blank">Instagram</a>. We are also holding an open house next Sunday with details below. Be sure to save the date as we only have one lot remaining for sale at Hudson Woods.</p><p>Open House:<br>Sunday, August 13th from 12-2 PM<br>101 Ridgewood Rd. Kerhonkson, NY 12446<br><br><br><img src="https://hudsonwoods.com/assets/img/journal/resized/7-20170803115529.jpg"><br></p><p><img src="/assets/img/journal/resized/2-20170803115434.jpg"></p><p><img src="/assets/img/journal/resized/3-20170803115440.jpg"></p><p><img src="/assets/img/journal/resized/6-20170803115508.jpg"><br></p><p><img src="/assets/img/journal/resized/5-20170803115522.jpg"></p><p><img src="/assets/img/journal/resized/1-20170803130521.jpg"></p><br>