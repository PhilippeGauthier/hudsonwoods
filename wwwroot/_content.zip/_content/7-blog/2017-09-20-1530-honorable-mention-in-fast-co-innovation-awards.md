---
title: "Open House + Honorable Mention in Fast Co's Innovation Awards"
author: HudsonWoods
featuredImage: /assets/img/journal/fastco.jpg
categories:
  - news
  - awards
  - design
contentSummary: "<p>Hudson Woods was awarded an Honorable Mention as part of Fast Company's 2017 Innovation by Design Awards under the Space, Places and Cities category. The awards represent the best products, services, interfaces, and ideas of 2017 across 13 categories. The Spaces, Places and Cities category looks at projects that improve the urban fabric, including urban planning, architecture, and interactive products. </p>"
---
<p><img src="/assets/img/journal/resized/awards-logo-adj_561-20170915123030.png"><br>Hudson Woods was awarded an Honorable Mention as part of Fast Company's 2017 Innovation by Design Awards under the Space, Places and Cities category.  The awards represent the best products, services, interfaces, and ideas of 2017 across 13 categories. The Spaces, Places and Cities category looks at projects that improve the urban fabric, including urban planning, architecture, and interactive products. Lang Architecture, the firm behind Hudson Woods, found itself among a roster of esteemed industry veterans including Heatherwick Studio, OMA, Gensler and Skidmore, Owings & Merrill. You can learn more here about the awards: <a href="https://www.fastcodesign.com/innovation-by-design/2017/category/spaces-places-and-cities">https://www.fastcodesign.com/innovation-by-design/...</a></p><p><span class="redactor-invisible-space"></span></p><p>Please also join us for an open house this Sunday with details below.</p><p><strong>Open House:<br></strong>Sunday Sep. 24th 12:00 - 2:00 PM<br>Hosted by Architect, Drew Lang<br>101 Ridgewood Rd. Kerhonkson, NY 12446</p>