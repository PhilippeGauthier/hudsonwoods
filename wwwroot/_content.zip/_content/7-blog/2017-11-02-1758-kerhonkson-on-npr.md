---
title: Open House + A $50 Billion multi-national in Kerhonkson
author: HudsonWoods
featuredImage: /assets/img/journal/1-20171102100607.jpg
categories:
  - news
  - community
contentSummary: '<p>Two years ago, one of the biggest companies in the world bought a failing hotel in a tiny rural hamlet in upstate New York. That made Planet Money reporter Noel King, curious. She grew up in the town and worked at the hotel as a teenager. Why, she wondered, would a multi-billion-dollar Chinese company invest in her hometown?</p>'
---
<p><img src="/assets/img/journal/resized/1-20171102100627.jpg"></p><p><br>Two years ago, one of the biggest companies in the world bought a failing hotel in a tiny rural hamlet in upstate New York. That made Planet Money reporter Noel King, curious. She grew up in the town and worked at the hotel as a teenager. Why, she wondered, would a multi-billion-dollar Chinese company invest in her hometown? <a href="http://www.npr.org/sections/money/2017/10/27/560407035/episode-802-the-hotel-at-the-center-of-the-world" target="_blank">Click Here</a> for the full podcast. </p><p>Please also join us for an open house this Sunday with details below.</p><p><strong>Open House:<br></strong>Sunday Nov. 12th 12:00 - 2:00 PM<br>Hosted by Architect, Drew Lang<br>101 Ridgewood Rd. Kerhonkson, NY 12446<br><br></p><p><img src="/assets/img/journal/resized/2-20171102100756.jpg"><br></p>