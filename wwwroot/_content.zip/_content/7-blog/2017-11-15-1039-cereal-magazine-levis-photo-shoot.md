---
title: "Levi's and Cereal Magazine at Hudson Woods"
author: HudsonWoods
featuredImage: /assets/img/journal/1-Lead-20171106104023.jpg
categories:
  - photography
  - press
  - fashion
contentSummary: "<p>Cereal Magazine recently stopped by the Hudson Woods to capture some photography for Levi's Made & Crafted. We choose a selection of the resulting photos below and you can learn more on the Cereal website.</p>"
---
<p><img src="/assets/img/journal/resized/1-Lead-20171106104030.jpg"></p><p>Cereal Magazine recently stopped by the Hudson Woods to capture some photography for Levi's Made & Crafted. We choose a selection of the resulting photos below and you can learn more on the Cereal website here: <a href="https://readcereal.com/hudson-woods/">https://readcereal.com/hudson-woods/</a></p><p><img src="/assets/img/journal/resized/2-20171106110337.jpg"></p><p><img src="/assets/img/journal/resized/3-20171106110344.jpg"></p><p><img src="/assets/img/journal/resized/4-20171106110357.jpg"></p><p><img src="/assets/img/journal/resized/5-20171106110405.jpg"></p><p><img src="/assets/img/journal/resized/6-20171106110409.jpg"></p><p><img src="/assets/img/journal/resized/7-20171106110413.jpg"></p><p><img src="/assets/img/journal/resized/8-20171106110417.jpg"></p><p><img src="/assets/img/journal/resized/9-20171106110421.jpg"></p><p><img src="/assets/img/journal/resized/10-20171106110425.jpg"></p><p><img src="/assets/img/journal/resized/11-20171106110429.jpg"></p>