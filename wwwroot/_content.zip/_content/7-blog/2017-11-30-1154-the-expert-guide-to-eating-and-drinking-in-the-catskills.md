---
title: 'The Expert Guide to Eating & Drinking in the Catskills'
author: HudsonWoods
categories:
  - community
  - 'food & drink'
  - catskills
featuredImage: /assets/img/journal/tl-horizontal_main.jpg
contentSummary: '<p>Since launching Hudson Woods 3 years ago, the community around the Catskills has grown and evolved tremendously. The growth is spurred by the local culture around food and drink. Access to local farms and fresh produce creates the perfect conditions for new restaurants. A number of breweries, wineries and restaurants have joined the fray adding to venerable destinations already in place. Thrillist put together a list of 16 places worth a sojourn. We wanted to share the list with you. </p>'
---
<p><img src="/assets/img/journal/resized/tl-horizontal_main-20171130115545.jpg"></p><p>Since launching Hudson Woods 3 years ago, the community around the Catskills has grown and evolved tremendously. The growth is spurred by the local culture around food and drink. Access to local farms and fresh produce creates the perfect conditions for new restaurants. A number of breweries, wineries and restaurants have joined the fray adding to venerable destinations already in place. Thrillist put together a list of 16 places worth a sojourn. We wanted to share the list with you. You can find the full list at this link: <a href="https://www.thrillist.com/travel/new-york/where-to-eat-and-drink-in-the-catskills-according-to-experts">https://www.thrillist.com/travel/new-york/where-to...</a></p>