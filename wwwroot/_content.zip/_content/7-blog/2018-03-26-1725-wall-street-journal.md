---
title: 'Hudson Woods Recently Featured in The Wall Street Journal '
author: HudsonWoods
featuredImage: /assets/img/journal/HW.jpg
buttons: ""
contentSummary: '<p>Hudson Woods was recently featured in a Wall Street Journal article about the rise of “Agrihood” communities. The article includes Bill Caleo, a home owner at Hudson Woods, and Brooklyn based real estate developer whose firm The Brooklyn Home Company creates innovative homes in Brooklyn.</p>'
---
<p><img src="/assets/img/journal/resized/HW-20180326173102.jpg"></p><p>Hudson Woods was recently featured in a Wall Street Journal article about the rise of “Agrihood” communities. The article includes Bill Caleo, a home owner at Hudson Woods, and Brooklyn based real estate developer whose firm <a href="http://www.thebrooklynhomecompany.com/" target="_blank">The Brooklyn Home Company</a> creates innovative homes in Brooklyn. Bill said of Hudson Woods, “It created this world for me that I could envision my family being part of.” You can find the article  You can find the article <a href="https://www.wsj.com/articles/live-like-a-farmer-minus-the-dirt-1521123467" target="_blank">here</a> and read it below.</p><p><img src="/assets/img/journal/resized/WSJ-Agrihoods-2-20180326191909.jpg"></p><br>