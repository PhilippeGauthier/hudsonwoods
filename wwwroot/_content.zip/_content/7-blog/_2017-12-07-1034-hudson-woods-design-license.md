---
title: How to License a Hudson Woods Design
author: HudsonWoods
featuredImage: /assets/img/journal/7-20171201184638.jpg
categories:
  - architecture
  - construction
  - real estate
contentSummary: '<p>We have had many inquiries about building a Hudson Woods home at a location outside of Hudson Woods. It is possible to do so with a Hudson Woods design license. The license allows buyers to build Hudson Woods home anywhere they like.</p>'
buttons:
  - 
    button_text: Download Guide
    button_url: ""
    button_file: /assets/img/journal/HW CD License-20171204160245.pdf
  - 
    button_text: Inquire for Details
    button_url: https://hudsonwoods.com/contact
    button_file: ""
---
<p><img src="/assets/img/journal/resized/1-20171201184707.jpg"></p><p>We have had many inquiries about building a Hudson Woods home at a location outside of Hudson Woods. It is possible to do so with a Hudson Woods design license. The license allows buyers to build Hudson Woods home anywhere they like.</p><p>The first step is finding a location that is the right fit for home owners. This can mean a number of different things from lot size and price to natural characteristics like mountain views, dense woods or lakeside frontage. One thing to consider when purchasing land is the degree to which infrastructure is in place. This is a significant consideration in final construction cost of the home. Generally, we are happy to assist buyers with their land search process, particularly in the Hudson Valley where we have a network of friendly brokers who know the area well. <br></p><p>Once land is acquired, the next step is to purchase the license. Once the license is purchased, we provide all of the construction documents and resources necessary to build the home. The buyer must then hire a contractor who will receive these documents and secure all the required building permits. From there construction can start. Below we have included the Hudson Woods Licensing Guide as a starting point for this process and you can contact us to learn more!</p><p><img src="/assets/img/journal/resized/2-20171201184713.jpg"></p><p><img src="/assets/img/journal/resized/3-20171201184719.jpg"></p><p><img src="/assets/img/journal/resized/4-20171201184723.jpg"></p><p><img src="/assets/img/journal/resized/5-20171201184727.jpg"></p><p><img src="/assets/img/journal/resized/6-20171201184731.jpg"></p><p><img src="/assets/img/journal/resized/7-20171201184735.jpg"></p><p><img src="/assets/img/journal/resized/8-20171201184738.jpg"></p><p><img src="/assets/img/journal/resized/9-20171201184742.jpg"></p><p><img src="/assets/img/journal/resized/10.JPG"></p><p><img src="/assets/img/journal/resized/11.jpeg"></p><p><img src="/assets/img/journal/resized/12-20171201184755.png"></p><p><img src="/assets/img/journal/resized/13-20171201184759.jpg"></p><p><img src="/assets/img/journal/resized/14-20171201184926.jpg"></p><p><img src="/assets/img/journal/resized/15-20171201184934.jpg"></p><p><img src="/assets/img/journal/resized/16-20171201184938.jpg"></p><p><img src="/assets/img/journal/resized/17-20171201184942.jpg"></p><p><img src="/assets/img/journal/resized/18.JPG"></p><p><img src="/assets/img/journal/resized/19.JPG"></p>